#!/usr/bin/env python3
"""
Check mobile testing environment setup for iOS and Android.
"""
import subprocess
import sys
import os

def check_appium_installation():
    """Check if Appium is installed and running."""
    print("🔍 Checking Appium installation...")
    try:
        result = subprocess.run(['appium', '--version'], capture_output=True, text=True)
        if result.returncode == 0:
            print(f"✅ Appium version: {result.stdout.strip()}")
            return True
        else:
            print("❌ Appium not found or not working")
            return False
    except FileNotFoundError:
        print("❌ Appium not installed")
        return False

def check_ios_environment():
    """Check iOS development environment."""
    print("\n🍎 Checking iOS environment...")
    
    # Check Xcode
    try:
        result = subprocess.run(['xcodebuild', '-version'], capture_output=True, text=True)
        if result.returncode == 0:
            print(f"✅ Xcode: {result.stdout.strip()}")
        else:
            print("❌ Xcode not found")
            return False
    except FileNotFoundError:
        print("❌ Xcode not installed")
        return False
    
    # Check iOS Simulator
    try:
        result = subprocess.run(['xcrun', 'simctl', 'list', 'devices'], capture_output=True, text=True)
        if result.returncode == 0:
            print("✅ iOS Simulator available")
            # Parse available devices
            lines = result.stdout.split('\n')
            for line in lines:
                if 'iPhone' in line and 'Booted' in line:
                    print(f"✅ Found booted device: {line.strip()}")
        else:
            print("❌ iOS Simulator not available")
    except FileNotFoundError:
        print("❌ iOS Simulator not found")
    
    return True

def check_android_environment():
    """Check Android development environment."""
    print("\n🤖 Checking Android environment...")
    
    # Check Android SDK
    android_home = os.environ.get('ANDROID_HOME') or os.environ.get('ANDROID_SDK_ROOT')
    if android_home:
        print(f"✅ ANDROID_HOME: {android_home}")
    else:
        print("❌ ANDROID_HOME not set")
        return False
    
    # Check adb
    try:
        result = subprocess.run(['adb', 'version'], capture_output=True, text=True)
        if result.returncode == 0:
            print(f"✅ ADB: {result.stdout.split('\n')[0]}")
        else:
            print("❌ ADB not working")
            return False
    except FileNotFoundError:
        print("❌ ADB not found")
        return False
    
    # Check connected devices
    try:
        result = subprocess.run(['adb', 'devices'], capture_output=True, text=True)
        if result.returncode == 0:
            lines = result.stdout.strip().split('\n')[1:]  # Skip header
            devices = [line for line in lines if line.strip() and 'device' in line]
            if devices:
                print(f"✅ Found {len(devices)} connected device(s)")
                for device in devices:
                    print(f"   - {device}")
            else:
                print("⚠️ No devices connected")
        else:
            print("❌ Could not list devices")
    except Exception as e:
        print(f"❌ Error checking devices: {e}")
    
    return True

def check_python_dependencies():
    """Check Python dependencies for mobile testing."""
    print("\n🐍 Checking Python dependencies...")
    
    required_packages = [
        'appium-python-client',
        'selenium'
    ]
    
    for package in required_packages:
        try:
            if package == 'appium-python-client':
                import appium
                print(f"✅ {package} installed")
            else:
                __import__(package.replace('-', '_'))
                print(f"✅ {package} installed")
        except ImportError:
            print(f"❌ {package} not installed")
            return False
    
    return True

def main():
    """Main function to check all mobile testing requirements."""
    print("📱 Mobile Testing Environment Check")
    print("=" * 50)
    
    all_good = True
    
    # Check Python dependencies
    if not check_python_dependencies():
        all_good = False
    
    # Check Appium
    if not check_appium_installation():
        all_good = False
    
    # Check iOS environment
    if not check_ios_environment():
        all_good = False
    
    # Check Android environment
    if not check_android_environment():
        all_good = False
    
    print("\n" + "=" * 50)
    if all_good:
        print("🎉 Mobile testing environment is ready!")
        print("\n📋 Next steps:")
        print("1. Start Appium server: appium")
        print("2. Connect iOS device/simulator")
        print("3. Connect Android device/emulator")
        print("4. Run mobile tests from QA Test Management")
    else:
        print("❌ Mobile testing environment needs setup")
        print("\n🔧 Setup instructions:")
        print("1. Install Appium: npm install -g appium")
        print("2. Install Xcode for iOS testing")
        print("3. Install Android SDK for Android testing")
        print("4. Set ANDROID_HOME environment variable")
        print("5. Connect devices or start simulators")

if __name__ == "__main__":
    main() 