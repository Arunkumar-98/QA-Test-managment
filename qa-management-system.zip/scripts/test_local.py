#!/usr/bin/env python3
"""
Simple test script for local automation
"""

import time
from typing import Optional

# Selenium imports
try:
    from selenium import webdriver
    from selenium.webdriver.chrome.service import Service
    from selenium.webdriver.chrome.options import Options
    from selenium.webdriver.common.by import By
    from selenium.webdriver.support.ui import WebDriverWait
    from selenium.webdriver.support import expected_conditions as EC
    from webdriver_manager.chrome import ChromeDriverManager
    SELENIUM_AVAILABLE = True
except ImportError:
    SELENIUM_AVAILABLE = False
    print("⚠️ Selenium not available - install with: pip install selenium webdriver-manager")

def test_google_search() -> bool:
    """Test Google search automation"""
    if not SELENIUM_AVAILABLE:
        print("❌ Selenium not available")
        return False
        
    print("🚀 Starting Google search test...")
    
    # Setup Chrome options
    chrome_options = Options()
    chrome_options.add_argument("--headless")  # Run in background
    chrome_options.add_argument("--no-sandbox")
    chrome_options.add_argument("--disable-dev-shm-usage")
    
    try:
        # Setup WebDriver
        service = Service(ChromeDriverManager().install())
        driver = webdriver.Chrome(service=service, options=chrome_options)
        
        # Navigate to Google
        print("📱 Going to Google...")
        driver.get("https://www.google.com")
        
        # Find search box and search
        search_box = driver.find_element(By.NAME, "q")
        search_box.send_keys("QA Test Automation")
        search_box.submit()
        
        # Wait for results
        time.sleep(2)
        
        # Get page title
        title = driver.title
        print(f"📄 Page title: {title}")
        
        # Check if search worked
        if "search" in title.lower() or "google" in title.lower():
            print("✅ Google search test PASSED!")
            result = True
        else:
            print("❌ Google search test FAILED!")
            result = False
            
        driver.quit()
        return result
        
    except Exception as e:
        print(f"❌ Test failed: {e}")
        return False

if __name__ == "__main__":
    print("🎯 Local Automation Test")
    print("=" * 40)
    
    success = test_google_search()
    
    if success:
        print("\n🎉 All tests passed! Your local automation is working!")
    else:
        print("\n⚠️ Some tests failed. Check the errors above.") 