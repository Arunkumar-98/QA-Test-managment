#!/usr/bin/env python3
"""
Sample Test Script for QA Test Management
This script demonstrates basic Selenium automation
"""

import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager

def main():
    print("🚀 Starting Sample Test Automation")
    print("=" * 50)
    
    try:
        # Setup Chrome driver
        print("📦 Setting up Chrome WebDriver...")
        service = Service(ChromeDriverManager().install())
        driver = webdriver.Chrome(service=service)
        
        # Navigate to a test page
        print("🌐 Navigating to test page...")
        driver.get("https://www.google.com")
        
        # Wait for page to load
        wait = WebDriverWait(driver, 10)
        search_box = wait.until(EC.presence_of_element_located((By.NAME, "q")))
        
        # Perform a simple test
        print("🔍 Performing search test...")
        search_box.send_keys("QA Test Automation")
        search_box.submit()
        
        # Wait for results
        time.sleep(2)
        
        # Check if results are present
        results = driver.find_elements(By.CSS_SELECTOR, "div.g")
        if results:
            print(f"✅ Test PASSED: Found {len(results)} search results")
            result = "PASS"
        else:
            print("❌ Test FAILED: No search results found")
            result = "FAIL"
            
    except Exception as e:
        print(f"❌ Test FAILED with error: {str(e)}")
        result = "FAIL"
        
    finally:
        try:
            driver.quit()
            print("🔒 Browser closed successfully")
        except:
            pass
    
    print("=" * 50)
    print(f"🏁 Test completed with result: {result}")
    
    # Return result for the automation system
    return result

if __name__ == "__main__":
    main() 