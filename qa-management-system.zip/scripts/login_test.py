#!/usr/bin/env python3
"""
Login Test Script for QA Test Management
This script demonstrates a login automation test
"""

import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager

def main():
    print("🔐 Starting Login Test Automation")
    print("=" * 50)
    
    try:
        # Setup Chrome driver
        print("📦 Setting up Chrome WebDriver...")
        service = Service(ChromeDriverManager().install())
        driver = webdriver.Chrome(service=service)
        
        # Navigate to a demo login page
        print("🌐 Navigating to demo login page...")
        driver.get("https://demo.testfire.net/login.jsp")
        
        # Wait for page to load
        wait = WebDriverWait(driver, 10)
        
        # Find and fill username
        print("👤 Entering username...")
        username_field = wait.until(EC.presence_of_element_located((By.ID, "uid")))
        username_field.send_keys("admin")
        
        # Find and fill password
        print("🔑 Entering password...")
        password_field = driver.find_element(By.ID, "passw")
        password_field.send_keys("admin")
        
        # Click login button
        print("🚀 Clicking login button...")
        login_button = driver.find_element(By.NAME, "btnSubmit")
        login_button.click()
        
        # Wait for login to complete
        time.sleep(3)
        
        # Check if login was successful
        try:
            # Look for welcome message or dashboard element
            welcome_element = wait.until(EC.presence_of_element_located((By.XPATH, "//*[contains(text(), 'Welcome')]")))
            print("✅ Login test PASSED: Successfully logged in")
            result = "PASS"
        except:
            print("❌ Login test FAILED: Could not find welcome message")
            result = "FAIL"
            
    except Exception as e:
        print(f"❌ Login test FAILED with error: {str(e)}")
        result = "FAIL"
        
    finally:
        try:
            driver.quit()
            print("🔒 Browser closed successfully")
        except:
            pass
    
    print("=" * 50)
    print(f"🏁 Login test completed with result: {result}")
    
    return result

if __name__ == "__main__":
    main() 