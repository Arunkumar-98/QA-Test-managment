#!/usr/bin/env python3
"""
Robust script to open the Notes tab and click the first note card using precise card properties.
"""
import time
import os
import datetime
from appium import webdriver
from appium.options.ios import XCUITestOptions
from selenium.webdriver.common.by import By

def open_first_note():
    print("\n🚀 Open Notes Tab and First Note Card (Robust)")
    screenshots_folder = "screenshots"
    os.makedirs(screenshots_folder, exist_ok=True)
    desired_caps = {
        "platformName": "iOS",
        "deviceName": "iPhone 8 Plus",
        "automationName": "XCUITest",
        "udid": "22120b0d1891bd1b74d6dc034d51c101ab187e35",
        "bundleId": "ai.oncall",
        "xcodeOrgId": "HHG2D2HWVC",
        "xcodeSigningId": "iPhone Developer",
        "updatedWDABundleId": "com.arunkumar.WebDriverAgentRunner",
        "noReset": True,
        "newCommandTimeout": 300,
        "wdaLaunchTimeout": 120000,
        "wdaConnectionTimeout": 120000,
        "useNewWDA": False,
        "autoAcceptAlerts": True
    }
    options = XCUITestOptions()
    for key, value in desired_caps.items():
        options.set_capability(key, value)
    driver = None
    try:
        print("\n📱 Launching App...")
        driver = webdriver.Remote("http://127.0.0.1:4723", options=options)
        time.sleep(3)
        # Go to Notes tab
        try:
            notes_tab = driver.find_element(By.XPATH, "//XCUIElementTypeButton[contains(@name, 'Notes')]")
            notes_tab.click()
            time.sleep(2)
            print("✅ Notes tab opened")
        except:
            print("ℹ️ Notes tab already active")
        driver.save_screenshot(os.path.join(screenshots_folder, "before_note_tap.png"))
        # Find the first note card using robust properties
        try:
            card = driver.find_element(
                By.XPATH,
                "//XCUIElementTypeOther[@x=32 and @width=350 and @height=107 and @enabled='true' and @visible='true']"
            )
            loc = card.location
            sz = card.size
            tap_x = loc['x'] + sz['width']//2
            tap_y = loc['y'] + sz['height']//2
            print(f"✅ Tapping first note card at ({tap_x}, {tap_y})")
            driver.tap([(tap_x, tap_y)], 1000)
            time.sleep(2)
            driver.save_screenshot(os.path.join(screenshots_folder, "after_note_tap.png"))
            print("✅ First note opened (check screenshots for confirmation)")
        except Exception as e:
            print(f"❌ Could not find or tap the first note card: {e}")
        # --- New: Extract transcript text and save to file ---
        try:
            print("🔍 Extracting transcript text...")
            # Find the largest visible text element in the Transcription tab
            text_elements = driver.find_elements(By.XPATH, "//XCUIElementTypeTextView | //XCUIElementTypeStaticText | //XCUIElementTypeOther")
            # Filter for visible, enabled, and substantial text
            candidates = []
            for elem in text_elements:
                try:
                    val = elem.get_attribute('value') or elem.text or elem.get_attribute('label') or ''
                    if len(val) > 100 and elem.get_attribute('visible') == 'true' and elem.get_attribute('enabled') == 'true':
                        candidates.append((elem, val))
                except:
                    continue
            if not candidates:
                print("❌ No suitable transcript text element found.")
            else:
                # Use the element with the most text
                transcript_elem, _ = max(candidates, key=lambda x: len(x[1]))
                full_text = ""
                last_text = ""
                scroll_attempts = 0
                max_scrolls = 10
                while scroll_attempts < max_scrolls:
                    current_text = transcript_elem.get_attribute('value') or transcript_elem.text or transcript_elem.get_attribute('label') or ''
                    if current_text == last_text:
                        break  # No new text, end
                    if current_text not in full_text:
                        full_text += current_text + "\n"
                    last_text = current_text
                    # Try to scroll up in the transcript area
                    rect = transcript_elem.rect
                    start_x = rect['x'] + rect['width']//2
                    start_y = rect['y'] + rect['height'] - 10
                    end_x = start_x
                    end_y = rect['y'] + 10
                    driver.swipe(start_x, start_y, end_x, end_y, 800)
                    time.sleep(1)
                    scroll_attempts += 1
                # Save to file
                all_lines = full_text.strip().split('\n')
                # Join with double line breaks for readability
                formatted_text = '\n\n'.join(all_lines)
                # Generate unique filename
                timestamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
                filename = f'transcript_{timestamp}.txt'
                with open(filename, 'w', encoding='utf-8') as f:
                    f.write(formatted_text.strip())
                print(f"✅ Transcript extracted and saved to {filename} ({len(formatted_text)} chars)")
        except Exception as e:
            print(f"❌ Could not extract or save transcript: {e}")
    except Exception as e:
        print(f"❌ Failed: {e}")
    finally:
        if driver:
            driver.quit()
            print("🔚 Driver session ended")

if __name__ == "__main__":
    open_first_note() 