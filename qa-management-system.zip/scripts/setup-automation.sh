#!/bin/bash

# QA Test Management - Automation Setup Script
# This script automatically installs all required dependencies for running test automation

echo "🚀 Setting up QA Test Management Automation Environment..."

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to check if command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Function to install Python dependencies
install_python_deps() {
    echo -e "${BLUE}📦 Installing Python dependencies...${NC}"
    
    # Create requirements.txt if it doesn't exist
    if [ ! -f "scripts/requirements.txt" ]; then
        cat > scripts/requirements.txt << EOF
selenium==4.15.2
webdriver-manager==4.0.1
pytest==7.4.3
pytest-html==4.1.1
requests==2.31.0
beautifulsoup4==4.12.2
lxml==4.9.3
EOF
    fi
    
    # Install Python dependencies
    if command_exists pip3; then
        pip3 install -r scripts/requirements.txt
    elif command_exists pip; then
        pip install -r scripts/requirements.txt
    else
        echo -e "${RED}❌ pip not found. Please install Python and pip first.${NC}"
        return 1
    fi
}

# Function to setup Chrome WebDriver
setup_chromedriver() {
    echo -e "${BLUE}🌐 Setting up Chrome WebDriver...${NC}"
    
    # Create webdriver setup script
    cat > scripts/setup_webdriver.py << 'EOF'
#!/usr/bin/env python3
"""
WebDriver Setup Script
Automatically downloads and configures Chrome WebDriver
"""

import os
import sys
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager

def setup_chromedriver():
    try:
        print("🔧 Setting up Chrome WebDriver...")
        
        # Download and setup ChromeDriver
        service = Service(ChromeDriverManager().install())
        
        # Test the setup
        options = webdriver.ChromeOptions()
        options.add_argument('--headless')  # Run in headless mode
        options.add_argument('--no-sandbox')
        options.add_argument('--disable-dev-shm-usage')
        
        driver = webdriver.Chrome(service=service, options=options)
        driver.get("https://www.google.com")
        print("✅ Chrome WebDriver setup successful!")
        driver.quit()
        
        return True
    except Exception as e:
        print(f"❌ Chrome WebDriver setup failed: {e}")
        return False

if __name__ == "__main__":
    success = setup_chromedriver()
    sys.exit(0 if success else 1)
EOF

    # Make it executable
    chmod +x scripts/setup_webdriver.py
    
    # Run the setup
    python3 scripts/setup_webdriver.py
}

# Function to create sample test templates
create_test_templates() {
    echo -e "${BLUE}📝 Creating sample test templates...${NC}"
    
    # Create a comprehensive test template
    cat > scripts/test_template.py << 'EOF'
#!/usr/bin/env python3
"""
Test Template for QA Test Management
Copy this file and modify for your specific test cases
"""

import sys
import time
import argparse
from datetime import datetime
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager

class TestRunner:
    def __init__(self, headless=True):
        self.headless = headless
        self.driver = None
        self.wait = None
        
    def setup_driver(self):
        """Setup Chrome WebDriver"""
        try:
            print(f"[{datetime.now()}] Setting up Chrome WebDriver...")
            
            # Setup Chrome options
            options = Options()
            if self.headless:
                options.add_argument('--headless')
            options.add_argument('--no-sandbox')
            options.add_argument('--disable-dev-shm-usage')
            options.add_argument('--disable-gpu')
            options.add_argument('--window-size=1920,1080')
            
            # Setup service and driver
            service = Service(ChromeDriverManager().install())
            self.driver = webdriver.Chrome(service=service, options=options)
            self.wait = WebDriverWait(self.driver, 10)
            
            print("✅ WebDriver setup complete")
            return True
            
        except Exception as e:
            print(f"❌ WebDriver setup failed: {e}")
            return False
    
    def run_test(self):
        """Main test execution"""
        try:
            print(f"[{datetime.now()}] Starting test execution...")
            
            # Example test steps - modify these for your specific test
            print("Step 1: Navigate to test website...")
            self.driver.get("https://example.com")
            
            print("Step 2: Find and interact with elements...")
            # Example: Find a button and click it
            # button = self.wait.until(EC.element_to_be_clickable((By.ID, "test-button")))
            # button.click()
            
            print("Step 3: Verify expected results...")
            # Example: Check if page title is correct
            # assert "Expected Title" in self.driver.title
            
            print("✅ Test completed successfully!")
            return True
            
        except Exception as e:
            print(f"❌ Test failed: {e}")
            return False
    
    def cleanup(self):
        """Clean up resources"""
        if self.driver:
            self.driver.quit()
            print("🧹 WebDriver cleaned up")

def main():
    parser = argparse.ArgumentParser(description='Test Template Runner')
    parser.add_argument('--headless', action='store_true', help='Run in headless mode')
    args = parser.parse_args()
    
    runner = TestRunner(headless=args.headless)
    
    try:
        if not runner.setup_driver():
            sys.exit(1)
        
        success = runner.run_test()
        sys.exit(0 if success else 1)
        
    finally:
        runner.cleanup()

if __name__ == "__main__":
    main()
EOF

    # Create a simple login test example
    cat > scripts/login_test_example.py << 'EOF'
#!/usr/bin/env python3
"""
Login Test Example
Demonstrates how to create a real login test
"""

import sys
import time
import argparse
from datetime import datetime
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager

def run_login_test(headless=True):
    driver = None
    try:
        print(f"[{datetime.now()}] Starting Login Test")
        print(f"Headless Mode: {headless}")
        
        # Setup WebDriver
        options = Options()
        if headless:
            options.add_argument('--headless')
        options.add_argument('--no-sandbox')
        options.add_argument('--disable-dev-shm-usage')
        
        service = Service(ChromeDriverManager().install())
        driver = webdriver.Chrome(service=service, options=options)
        wait = WebDriverWait(driver, 10)
        
        # Test steps
        print("Step 1: Navigate to login page...")
        driver.get("https://example.com/login")  # Replace with your login URL
        
        print("Step 2: Enter username...")
        username_field = wait.until(EC.presence_of_element_located((By.NAME, "username")))
        username_field.send_keys("testuser")  # Replace with test credentials
        
        print("Step 3: Enter password...")
        password_field = driver.find_element(By.NAME, "password")
        password_field.send_keys("testpass")  # Replace with test credentials
        
        print("Step 4: Click login button...")
        login_button = driver.find_element(By.XPATH, "//button[@type='submit']")
        login_button.click()
        
        print("Step 5: Verify successful login...")
        # Wait for redirect or success message
        wait.until(EC.presence_of_element_located((By.CLASS_NAME, "dashboard")))
        
        print("✅ Login test completed successfully!")
        return True
        
    except Exception as e:
        print(f"❌ Login test failed: {e}")
        return False
        
    finally:
        if driver:
            driver.quit()

def main():
    parser = argparse.ArgumentParser(description='Login Test Example')
    parser.add_argument('--headless', action='store_true', help='Run in headless mode')
    args = parser.parse_args()
    
    success = run_login_test(headless=args.headless)
    sys.exit(0 if success else 1)

if __name__ == "__main__":
    main()
EOF

    # Make templates executable
    chmod +x scripts/test_template.py
    chmod +x scripts/login_test_example.py
}

# Function to create Docker setup (alternative)
create_docker_setup() {
    echo -e "${BLUE}🐳 Creating Docker setup...${NC}"
    
    cat > Dockerfile.automation << 'EOF'
FROM python:3.11-slim

# Install system dependencies
RUN apt-get update && apt-get install -y \
    wget \
    gnupg \
    unzip \
    && rm -rf /var/lib/apt/lists/*

# Install Chrome
RUN wget -q -O - https://dl.google.com/linux/linux_signing_key.pub | apt-key add - \
    && echo "deb [arch=amd64] http://dl.google.com/linux/chrome/deb/ stable main" >> /etc/apt/sources.list.d/google.list \
    && apt-get update \
    && apt-get install -y google-chrome-stable \
    && rm -rf /var/lib/apt/lists/*

# Set working directory
WORKDIR /app

# Copy requirements and install Python dependencies
COPY scripts/requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# Copy scripts
COPY scripts/ ./scripts/

# Make scripts executable
RUN chmod +x scripts/*.py

# Default command
CMD ["python3", "scripts/test_template.py"]
EOF

    cat > docker-compose.automation.yml << 'EOF'
version: '3.8'

services:
  automation:
    build:
      context: .
      dockerfile: Dockerfile.automation
    volumes:
      - ./scripts:/app/scripts
      - ./test-results:/app/test-results
    environment:
      - DISPLAY=:99
    command: python3 scripts/test_template.py --headless
EOF
}

# Function to create quick start guide
create_quick_start_guide() {
    echo -e "${BLUE}📖 Creating Quick Start Guide...${NC}"
    
    cat > AUTOMATION_QUICK_START.md << 'EOF'
# 🚀 Quick Start Guide - QA Test Automation

## Option 1: Automatic Setup (Recommended)

### 1. Run the setup script:
```bash
chmod +x scripts/setup-automation.sh
./scripts/setup-automation.sh
```

### 2. Test the setup:
```bash
python3 scripts/test_template.py --headless
```

## Option 2: Manual Setup

### 1. Install Python 3.8+ and pip

### 2. Install dependencies:
```bash
pip3 install selenium webdriver-manager pytest requests beautifulsoup4
```

### 3. Test the setup:
```bash
python3 scripts/setup_webdriver.py
```

## Option 3: Docker Setup (No local dependencies)

### 1. Build and run with Docker:
```bash
docker build -f Dockerfile.automation -t qa-automation .
docker run qa-automation
```

### 2. Or use Docker Compose:
```bash
docker-compose -f docker-compose.automation.yml up
```

## Creating Your Own Tests

### 1. Copy the template:
```bash
cp scripts/test_template.py scripts/my_test.py
```

### 2. Modify the test:
- Update the URL in `run_test()` method
- Add your specific test steps
- Add assertions for expected results

### 3. Run your test:
```bash
python3 scripts/my_test.py --headless
```

## Integration with QA Test Management

### 1. Configure in the app:
- Script Path: `./scripts/my_test.py`
- Command: `python3 ./scripts/my_test.py --headless`

### 2. Run from the interface:
- Click "Configure Automation" on a test case
- Set the script path and command
- Click "Run" to execute

## Troubleshooting

### Chrome WebDriver Issues:
```bash
python3 scripts/setup_webdriver.py
```

### Permission Issues:
```bash
chmod +x scripts/*.py
```

### Python Not Found:
- Install Python 3.8+ from python.org
- Add Python to your PATH

### Dependencies Issues:
```bash
pip3 install --upgrade -r scripts/requirements.txt
```

## Test Examples

### Basic Test:
```python
def run_test(self):
    self.driver.get("https://your-website.com")
    title = self.driver.title
    assert "Expected Title" in title
    return True
```

### Login Test:
```python
def run_test(self):
    self.driver.get("https://your-website.com/login")
    self.driver.find_element(By.NAME, "username").send_keys("user")
    self.driver.find_element(By.NAME, "password").send_keys("pass")
    self.driver.find_element(By.XPATH, "//button[@type='submit']").click()
    # Add verification steps
    return True
```

## Support

- Check the logs in the QA Test Management interface
- Review the test output for error messages
- Ensure all dependencies are installed correctly
EOF
}

# Main execution
main() {
    echo -e "${GREEN}🎯 QA Test Management Automation Setup${NC}"
    echo "================================================"
    
    # Check if Python is installed
    if ! command_exists python3 && ! command_exists python; then
        echo -e "${RED}❌ Python not found. Please install Python 3.8+ first.${NC}"
        echo -e "${YELLOW}Download from: https://www.python.org/downloads/${NC}"
        exit 1
    fi
    
    # Install dependencies
    install_python_deps
    
    # Setup WebDriver
    setup_chromedriver
    
    # Create templates
    create_test_templates
    
    # Create Docker setup
    create_docker_setup
    
    # Create quick start guide
    create_quick_start_guide
    
    echo -e "${GREEN}✅ Setup complete!${NC}"
    echo -e "${BLUE}📖 Check AUTOMATION_QUICK_START.md for usage instructions${NC}"
    echo -e "${YELLOW}🧪 Test the setup: python3 scripts/test_template.py --headless${NC}"
}

# Run main function
main "$@" 