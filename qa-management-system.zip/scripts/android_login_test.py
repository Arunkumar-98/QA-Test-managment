#!/usr/bin/env python3
"""
Android mobile test script for OnCall app login functionality.
"""
import time
import os
from appium import webdriver
from appium.options.android import UiAutomator2Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

def android_login_test():
    print("\n🤖 Android OnCall App Login Test")
    screenshots_folder = "screenshots"
    os.makedirs(screenshots_folder, exist_ok=True)
    
    # Android capabilities
    desired_caps = {
        "platformName": "Android",
        "deviceName": "Android Emulator",
        "automationName": "UiAutomator2",
        "appPackage": "ai.oncall",
        "appActivity": "ai.oncall.MainActivity",
        "noReset": True,
        "newCommandTimeout": 300,
        "autoGrantPermissions": True,
        "autoAcceptAlerts": True
    }
    
    options = UiAutomator2Options()
    for key, value in desired_caps.items():
        options.set_capability(key, value)
    
    driver = None
    try:
        print("\n📱 Launching Android App...")
        driver = webdriver.Remote("http://127.0.0.1:4723", options=options)
        time.sleep(5)
        
        # Take initial screenshot
        driver.save_screenshot(os.path.join(screenshots_folder, "android_initial_screen.png"))
        print("✅ App launched successfully")
        
        # Check if we're on login screen
        try:
            # Look for login elements
            username_field = WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.ID, "username_input"))
            )
            print("✅ Login screen detected")
            
            # Enter username
            username_field.clear()
            username_field.send_keys("test@example.com")
            print("✅ Username entered")
            
            # Find and enter password
            password_field = driver.find_element(By.ID, "password_input")
            password_field.clear()
            password_field.send_keys("password123")
            print("✅ Password entered")
            
            # Take screenshot before login
            driver.save_screenshot(os.path.join(screenshots_folder, "android_before_login.png"))
            
            # Click login button
            login_button = driver.find_element(By.ID, "login_button")
            login_button.click()
            print("✅ Login button clicked")
            
            # Wait for login to complete
            time.sleep(5)
            
            # Take screenshot after login
            driver.save_screenshot(os.path.join(screenshots_folder, "android_after_login.png"))
            
            # Check if login was successful
            try:
                # Look for main app elements
                main_content = WebDriverWait(driver, 10).until(
                    EC.presence_of_element_located((By.ID, "main_content"))
                )
                print("✅ Login successful - main app content found")
                
                # Navigate to Notes tab
                try:
                    notes_tab = driver.find_element(By.XPATH, "//android.widget.TextView[@text='Notes']")
                    notes_tab.click()
                    time.sleep(3)
                    print("✅ Notes tab opened")
                    
                    # Take screenshot of notes
                    driver.save_screenshot(os.path.join(screenshots_folder, "android_notes_screen.png"))
                    
                    # Try to find and click first note
                    try:
                        first_note = driver.find_element(By.XPATH, "//android.widget.CardView[1]")
                        first_note.click()
                        time.sleep(2)
                        print("✅ First note opened")
                        
                        # Take screenshot of note detail
                        driver.save_screenshot(os.path.join(screenshots_folder, "android_note_detail.png"))
                        
                    except Exception as e:
                        print(f"ℹ️ Could not open first note: {e}")
                        
                except Exception as e:
                    print(f"ℹ️ Could not navigate to Notes tab: {e}")
                
            except Exception as e:
                print(f"❌ Login may have failed: {e}")
                
        except Exception as e:
            print(f"ℹ️ May already be logged in or different screen: {e}")
            
            # Try to navigate to Notes directly
            try:
                notes_tab = driver.find_element(By.XPATH, "//android.widget.TextView[@text='Notes']")
                notes_tab.click()
                time.sleep(3)
                print("✅ Notes tab opened")
                driver.save_screenshot(os.path.join(screenshots_folder, "android_notes_screen.png"))
            except:
                print("ℹ️ Could not find Notes tab")
        
        print("✅ Android test completed successfully")
        
    except Exception as e:
        print(f"❌ Android test failed: {e}")
        if driver:
            driver.save_screenshot(os.path.join(screenshots_folder, "android_error_screen.png"))
    finally:
        if driver:
            driver.quit()
            print("🔚 Android driver session ended")

if __name__ == "__main__":
    android_login_test() 