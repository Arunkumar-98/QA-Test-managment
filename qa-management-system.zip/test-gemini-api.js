const { GoogleGenerativeAI } = require('@google/generative-ai');

// Test function to check Gemini API
async function testGeminiAPI() {
  try {
    // Get API key from environment variable
    const apiKey = process.env.GEMINI_API_KEY;
    
    if (!apiKey) {
      console.log('❌ GEMINI_API_KEY environment variable is not set');
      console.log('Please set your API key: export GEMINI_API_KEY="your-api-key-here"');
      return;
    }

    console.log('🔑 API Key found, testing connection...');
    
    // Initialize the model
    const genAI = new GoogleGenerativeAI(apiKey);
    
    // First, let's list available models
    console.log('📋 Checking available models...');
    try {
      const models = await genAI.listModels();
      console.log('✅ Available models:');
      models.models.forEach(model => {
        console.log(`  - ${model.name} (${model.displayName})`);
      });
    } catch (modelError) {
      console.log('⚠️ Could not list models, trying direct model access...');
    }

    // Try different model names
    const modelNames = ['gemini-1.5-pro', 'gemini-1.5-flash', 'gemini-pro', 'gemini-pro-vision'];
    
    for (const modelName of modelNames) {
      try {
        console.log(`\n🔄 Testing model: ${modelName}`);
        const model = genAI.getGenerativeModel({ model: modelName });

        // Simple test prompt
        const prompt = "Hello! Please respond with 'Gemini API is working!' if you can see this message.";

        console.log('📤 Sending test request...');
        
        // Generate content
        const result = await model.generateContent(prompt);
        const response = await result.response;
        const text = response.text();

        console.log('✅ Gemini API is working!');
        console.log(`📥 Response from ${modelName}:`, text);
        console.log('🎉 Your API key is valid and functional!');
        return; // Success, exit the function
        
      } catch (modelError) {
        console.log(`❌ Model ${modelName} failed:`, modelError.message);
        continue; // Try next model
      }
    }
    
    console.log('❌ All model attempts failed. Please check your API key and permissions.');

  } catch (error) {
    console.log('❌ Error testing Gemini API:');
    console.log('Error details:', error.message);
    
    if (error.message.includes('API_KEY_INVALID')) {
      console.log('🔑 Your API key appears to be invalid. Please check your key.');
    } else if (error.message.includes('QUOTA_EXCEEDED')) {
      console.log('📊 You may have exceeded your free tier quota.');
    } else if (error.message.includes('PERMISSION_DENIED')) {
      console.log('🚫 Permission denied. Check if your API key has the right permissions.');
    } else {
      console.log('🔍 Check your internet connection and try again.');
    }
  }
}

// Run the test
testGeminiAPI(); 