#!/bin/bash

# Create deployment zip file for QA Management System
echo "🚀 Creating deployment zip file..."

# Create a temporary directory for the deployment files
TEMP_DIR="qa-management-deployment"
rm -rf $TEMP_DIR
mkdir $TEMP_DIR

# Copy necessary files and directories
echo "📁 Copying project files..."

# Core application files
cp -r app $TEMP_DIR/
cp -r components $TEMP_DIR/
cp -r hooks $TEMP_DIR/
cp -r lib $TEMP_DIR/
cp -r types $TEMP_DIR/
cp -r public $TEMP_DIR/

# Configuration files
cp package.json $TEMP_DIR/
cp package-lock.json $TEMP_DIR/
cp next.config.mjs $TEMP_DIR/
cp tailwind.config.ts $TEMP_DIR/
cp tsconfig.json $TEMP_DIR/
cp postcss.config.mjs $TEMP_DIR/
cp components.json $TEMP_DIR/

# Documentation and deployment files
cp DEPLOYMENT.md $TEMP_DIR/
cp README.md $TEMP_DIR/ 2>/dev/null || echo "README.md not found, skipping..."

# SQL files for database setup
cp supabase-schema.sql $TEMP_DIR/
cp supabase-auth-schema.sql $TEMP_DIR/
cp status-history-schema.sql $TEMP_DIR/
cp fix-status-history-rls.sql $TEMP_DIR/

# Remove unnecessary files from copied directories
echo "🧹 Cleaning up unnecessary files..."

# Remove node_modules if it exists
rm -rf $TEMP_DIR/node_modules 2>/dev/null

# Remove .next directory if it exists
rm -rf $TEMP_DIR/.next 2>/dev/null

# Remove environment files
find $TEMP_DIR -name ".env*" -delete 2>/dev/null

# Remove log files
find $TEMP_DIR -name "*.log" -delete 2>/dev/null

# Remove TypeScript build info
find $TEMP_DIR -name "*.tsbuildinfo" -delete 2>/dev/null

# Remove screenshots directory (not needed for deployment)
rm -rf $TEMP_DIR/screenshots 2>/dev/null

# Create the zip file
echo "📦 Creating zip file..."
zip -r qa-management-system.zip $TEMP_DIR -x "*.DS_Store" "*/.*"

# Clean up temporary directory
rm -rf $TEMP_DIR

echo "✅ Deployment zip file created: qa-management-system.zip"
echo ""
echo "📋 Files included:"
echo "  ✅ Next.js application (app/, components/, hooks/, lib/, types/)"
echo "  ✅ Configuration files (package.json, next.config.mjs, etc.)"
echo "  ✅ Database schemas (SQL files)"
echo "  ✅ Documentation (DEPLOYMENT.md)"
echo ""
echo "📋 Files excluded:"
echo "  ❌ node_modules/"
echo "  ❌ .next/"
echo "  ❌ .env files"
echo "  ❌ Log files"
echo "  ❌ Screenshots"
echo "  ❌ Build artifacts"
echo ""
echo "🚀 Ready for deployment to Vercel!"
echo "📖 See DEPLOYMENT.md for setup instructions" 