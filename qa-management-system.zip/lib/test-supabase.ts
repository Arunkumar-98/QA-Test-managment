import { supabase } from './supabase'

export const testSupabaseConnection = async () => {
  try {
    console.log('🔍 Testing Supabase connection...')
    const { data, error } = await supabase
      .from('projects')
      .select('count')
      .single()
    
    if (error) {
      console.error('❌ Supabase connection test failed:', error)
      return { success: false, error }
    }
    
    console.log('✅ Supabase connection successful')
    return { success: true, data }
  } catch (error) {
    console.error('❌ Supabase connection test failed:', error)
    return { success: false, error }
  }
}

export const testTestCasesTable = async () => {
  try {
    console.log('🔍 Testing test_cases table...')
    const { data, error } = await supabase
      .from('test_cases')
      .select('count')
      .single()
    
    if (error) {
      console.error('❌ Test cases table test failed:', error)
      return { success: false, error }
    }
    
    console.log('✅ Test cases table accessible')
    return { success: true, data }
  } catch (error) {
    console.error('❌ Test cases table test failed:', error)
    return { success: false, error }
  }
}

// New function to debug data state
export const debugDataState = async () => {
  try {
    console.log('🔍 Debugging data state...')
    
    // Check projects
    const { data: projects, error: projectsError } = await supabase
      .from('projects')
      .select('*')
    
    if (projectsError) {
      console.error('❌ Error fetching projects:', projectsError)
    } else {
      console.log('📊 Projects in database:', projects)
    }
    
    // Check test cases
    const { data: testCases, error: testCasesError } = await supabase
      .from('test_cases')
      .select('id, test_case, project_id')
    
    if (testCasesError) {
      console.error('❌ Error fetching test cases:', testCasesError)
    } else {
      console.log('📊 Test cases in database:', testCases)
      console.log('📊 Test cases with project_id:', testCases?.filter(tc => tc.project_id))
      console.log('📊 Test cases without project_id:', testCases?.filter(tc => !tc.project_id))
    }
    
    return { success: true, projects, testCases }
  } catch (error) {
    console.error('❌ Debug data state failed:', error)
    return { success: false, error }
  }
} 