# Drag & Drop Test Case Reordering

## Overview

The Drag & Drop functionality allows you to reorder test cases in the table by dragging rows up and down. This feature provides an intuitive way to organize your test cases in a custom order without breaking any existing functionality.

## Features

### 🎯 **Intuitive Drag & Drop**
- **Visual drag handle**: Grip icon (⋮⋮) indicates draggable rows
- **Smooth animations**: Smooth transitions during drag operations
- **Visual feedback**: Rows become semi-transparent while dragging
- **Keyboard support**: Full accessibility with keyboard navigation

### 🔧 **Toggle Control**
- **Enable/Disable**: Toggle drag functionality on/off
- **Visual indicator**: Button shows current state (enabled/disabled)
- **Persistent state**: Remembers your preference during the session

### 📱 **Responsive Design**
- **Desktop optimized**: Full drag and drop experience
- **Mobile friendly**: Touch gestures supported
- **Cross-browser**: Works on all modern browsers

## How to Use

### Enabling Drag & Drop

1. **Locate the toggle button** in the header controls (next to Filters)
2. **Click "Drag & Drop"** to enable the feature
3. **Visual confirmation**: Button turns blue when enabled
4. **Drag handle appears**: Grip icons (⋮⋮) appear in the leftmost column

### Reordering Test Cases

1. **Hover over a row** to see the drag handle
2. **Click and hold** the grip icon (⋮⋮)
3. **Drag up or down** to the desired position
4. **Release** to drop the test case in its new position
5. **Confirmation**: Toast notification confirms the reorder

### Disabling Drag & Drop

1. **Click the "Drag & Drop" button** again
2. **Visual confirmation**: Button returns to normal state
3. **Drag handles disappear**: Grip icons are hidden
4. **Normal interaction**: Table returns to standard behavior

## Technical Implementation

### Dependencies
```json
{
  "@dnd-kit/core": "^6.0.0",
  "@dnd-kit/sortable": "^7.0.0", 
  "@dnd-kit/utilities": "^3.2.0"
}
```

### Key Components

#### DndContext
```typescript
<DndContext
  sensors={sensors}
  collisionDetection={closestCenter}
  onDragEnd={handleDragEnd}
>
  <SortableContext
    items={paginatedTestCases.map(testCase => testCase.id)}
    strategy={verticalListSortingStrategy}
  >
    {/* Sortable rows */}
  </SortableContext>
</DndContext>
```

#### SortableTableRow
```typescript
function SortableTableRow({ testCase, isDragEnabled, ...props }) {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id: testCase.id })

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
  }

  return (
    <TableRow ref={setNodeRef} style={style}>
      {isDragEnabled && (
        <TableCell>
          <div {...attributes} {...listeners}>
            <GripVertical className="w-4 h-4" />
          </div>
        </TableCell>
      )}
      {/* Other cells */}
    </TableRow>
  )
}
```

### State Management

#### Drag State
```typescript
const [isDragEnabled, setIsDragEnabled] = useState(true)
const [sortedTestCases, setSortedTestCases] = useState<TestCase[]>(testCases)
```

#### Drag Sensors
```typescript
const sensors = useSensors(
  useSensor(PointerSensor, {
    activationConstraint: {
      distance: 8, // Minimum drag distance
    },
  }),
  useSensor(KeyboardSensor, {
    coordinateGetter: sortableKeyboardCoordinates,
  })
)
```

#### Drag End Handler
```typescript
const handleDragEnd = (event: DragEndEvent) => {
  const { active, over } = event

  if (active.id !== over?.id) {
    setSortedTestCases((items) => {
      const oldIndex = items.findIndex((item) => item.id === active.id)
      const newIndex = items.findIndex((item) => item.id === over?.id)

      return arrayMove(items, oldIndex, newIndex)
    })

    toast({
      title: "Test Case Reordered",
      description: "The test case order has been updated.",
    })
  }
}
```

## User Experience

### Visual Feedback

#### Drag Handle
- **Grip icon**: Clear visual indicator for draggable area
- **Hover effect**: Background color changes on hover
- **Active state**: Cursor changes to grabbing during drag

#### Row States
- **Normal**: Full opacity, standard appearance
- **Dragging**: 50% opacity, visual feedback
- **Hover**: Subtle background color change

#### Button States
- **Disabled**: White background, normal border
- **Enabled**: Blue background, blue border, blue text

### Accessibility

#### Keyboard Navigation
- **Tab navigation**: Drag handle is keyboard accessible
- **Arrow keys**: Navigate between rows
- **Space/Enter**: Activate drag mode
- **Escape**: Cancel drag operation

#### Screen Reader Support
- **ARIA labels**: Proper labeling for drag handles
- **Role attributes**: Correct semantic roles
- **State announcements**: Drag state changes announced

### Performance

#### Optimizations
- **Virtual scrolling**: Only render visible rows
- **Efficient updates**: Minimal re-renders during drag
- **Smooth animations**: Hardware-accelerated transitions
- **Memory management**: Proper cleanup of event listeners

## Benefits

### 🎯 **Improved Organization**
- **Custom ordering**: Arrange test cases by priority, dependency, or workflow
- **Visual grouping**: Group related test cases together
- **Logical flow**: Create test execution sequences

### 🚀 **Enhanced Productivity**
- **Quick reordering**: No need to edit individual test cases
- **Bulk organization**: Move multiple test cases efficiently
- **Intuitive interface**: Natural drag and drop interaction

### 🔧 **Flexible Workflow**
- **Temporary ordering**: Reorder for specific testing sessions
- **Persistent preferences**: Maintain custom order during session
- **Easy reset**: Disable to return to default order

## Best Practices

### Organization Tips

#### Priority-Based Ordering
1. **High priority first**: Drag critical test cases to the top
2. **Dependency order**: Arrange dependent tests in sequence
3. **Execution flow**: Order by test execution requirements

#### Feature Grouping
1. **Related tests**: Group tests for the same feature
2. **Module organization**: Arrange by application modules
3. **Workflow sequence**: Order by user workflow steps

### Performance Considerations

#### Large Datasets
- **Pagination**: Drag within current page only
- **Virtual scrolling**: Efficient rendering for large lists
- **Batch operations**: Consider bulk reordering for efficiency

#### Browser Compatibility
- **Modern browsers**: Full functionality
- **Fallback support**: Graceful degradation
- **Touch devices**: Optimized for mobile interaction

## Troubleshooting

### Common Issues

#### Drag Not Working
- **Check toggle**: Ensure drag and drop is enabled
- **Browser support**: Verify modern browser compatibility
- **JavaScript errors**: Check browser console for errors

#### Performance Issues
- **Large datasets**: Consider pagination or virtual scrolling
- **Browser memory**: Refresh page if experiencing lag
- **Network issues**: Check for connectivity problems

#### Visual Glitches
- **CSS conflicts**: Ensure no conflicting styles
- **Z-index issues**: Check for overlapping elements
- **Animation conflicts**: Disable conflicting animations

### Support

For issues with drag and drop functionality:

1. **Check browser console** for error messages
2. **Verify dependencies** are properly installed
3. **Test in different browsers** to isolate issues
4. **Contact support** with specific error details

## Future Enhancements

### Planned Features
- **Multi-select drag**: Drag multiple selected test cases
- **Drag between pages**: Cross-page reordering
- **Undo/Redo**: Revert drag operations
- **Save order**: Persist custom ordering
- **Drag to suite**: Move test cases between suites

### Customization Options
- **Drag handle position**: Configurable handle location
- **Animation speed**: Adjustable transition timing
- **Visual themes**: Custom drag handle styles
- **Keyboard shortcuts**: Custom key bindings

---

*The Drag & Drop functionality provides an intuitive and efficient way to organize your test cases, enhancing your QA workflow without disrupting existing features.* 