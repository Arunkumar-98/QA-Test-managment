# Gemini API Key Testing Guide

## 🔑 How to Test Your Gemini API Key

### Step 1: Get Your API Key
1. Go to [Google AI Studio](https://makersuite.google.com/app/apikey)
2. Sign in with your Google account
3. Click "Create API Key"
4. Copy your API key (it starts with "AIza...")

### Step 2: Set Environment Variable
```bash
# Set your API key as an environment variable
export GEMINI_API_KEY="your-api-key-here"

# Or add it to your .env file
echo "GEMINI_API_KEY=your-api-key-here" >> .env
```

### Step 3: Run the Test Script
```bash
# Test your API key
node test-gemini-api.js
```

## 📊 Expected Results

### ✅ Success Response
```
🔑 API Key found, testing connection...
📤 Sending test request...
✅ Gemini API is working!
📥 Response: Gemini API is working!
🎉 Your API key is valid and functional!
```

### ❌ Common Error Responses

#### Invalid API Key
```
❌ Error testing Gemini API:
Error details: API_KEY_INVALID
🔑 Your API key appears to be invalid. Please check your key.
```

#### Quota Exceeded
```
❌ Error testing Gemini API:
Error details: QUOTA_EXCEEDED
📊 You may have exceeded your free tier quota.
```

#### Permission Denied
```
❌ Error testing Gemini API:
Error details: PERMISSION_DENIED
🚫 Permission denied. Check if your API key has the right permissions.
```

## 🆓 Free Tier Limits

### Gemini Pro (Free Tier)
- **Requests per minute**: 60
- **Requests per day**: 1,500
- **Characters per request**: 30,000
- **Characters per day**: 2,000,000

### Gemini Pro Vision (Free Tier)
- **Requests per minute**: 60
- **Requests per day**: 1,500
- **Characters per request**: 30,000
- **Characters per day**: 2,000,000

## 🔧 Alternative Testing Methods

### Method 1: Using cURL
```bash
curl -X POST \
  -H "Content-Type: application/json" \
  -d '{
    "contents": [{
      "parts": [{
        "text": "Hello! Please respond with 'Gemini API is working!'"
      }]
    }]
  }' \
  "https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=YOUR_API_KEY"
```

### Method 2: Using Python
```python
import google.generativeai as genai

# Configure the API key
genai.configure(api_key='YOUR_API_KEY')

# Test the API
model = genai.GenerativeModel('gemini-pro')
response = model.generate_content('Hello! Please respond with "Gemini API is working!"')
print(response.text)
```

### Method 3: Using Google AI Studio
1. Go to [Google AI Studio](https://makersuite.google.com/app/prompts)
2. Create a new prompt
3. Enter: "Hello! Please respond with 'Gemini API is working!'"
4. Click "Run" to test

## 🚨 Troubleshooting

### API Key Not Working?
1. **Check the key format**: Should start with "AIza"
2. **Verify it's active**: Check in Google AI Studio
3. **Check permissions**: Ensure API is enabled
4. **Check quota**: Verify you haven't exceeded limits

### Getting Rate Limited?
- **Wait a minute**: Free tier has rate limits
- **Check usage**: Monitor your quota in Google AI Studio
- **Upgrade**: Consider paid tier for higher limits

### Network Issues?
- **Check internet**: Ensure stable connection
- **Check firewall**: Ensure no blocking
- **Try VPN**: If region-restricted

## 📈 Monitoring Usage

### Check Your Usage
1. Go to [Google AI Studio](https://makersuite.google.com/app/apikey)
2. Click on your API key
3. View usage statistics and quotas

### Usage Dashboard
- **Daily requests**: Track your daily usage
- **Monthly requests**: Monitor monthly limits
- **Error rates**: Check for failed requests
- **Response times**: Monitor performance

## 🎯 Integration Tips

### For Your QA Application
```javascript
// Example integration in your app
const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
const model = genAI.getGenerativeModel({ model: "gemini-pro" });

async function generateTestCases(description) {
  const prompt = `Generate test cases for: ${description}`;
  const result = await model.generateContent(prompt);
  return result.response.text();
}
```

### Environment Variables
```bash
# .env file
GEMINI_API_KEY=your-api-key-here
GEMINI_MODEL=gemini-pro
GEMINI_MAX_TOKENS=1000
```

### Error Handling
```javascript
try {
  const result = await model.generateContent(prompt);
  return result.response.text();
} catch (error) {
  if (error.message.includes('QUOTA_EXCEEDED')) {
    console.log('API quota exceeded, please try again later');
  } else if (error.message.includes('API_KEY_INVALID')) {
    console.log('Invalid API key, please check your configuration');
  }
  throw error;
}
```

## 🔒 Security Best Practices

### API Key Security
- **Never commit to git**: Add `.env` to `.gitignore`
- **Use environment variables**: Don't hardcode in source
- **Rotate regularly**: Change keys periodically
- **Monitor usage**: Watch for unusual activity

### Rate Limiting
- **Implement backoff**: Retry with exponential delay
- **Cache responses**: Store common results
- **Batch requests**: Combine multiple prompts
- **Monitor quotas**: Track usage closely

---

*This guide helps you verify that your Gemini API key is working correctly and provides tips for integration and monitoring.* 