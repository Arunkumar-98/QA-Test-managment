# 🔧 Import Functionality Debug Guide

## 🚨 **Issue Identified: Authentication Required**

The import functionality requires the user to be **logged in** to work properly. The errors you're seeing are likely due to:

1. **User not authenticated** - Database operations require a valid user session
2. **Row Level Security (RLS)** - Database policies prevent unauthorized access
3. **Missing project ID** - Import needs a valid project context

## ✅ **How to Test the Import Functionality**

### **Step 1: Ensure You're Logged In**
1. **Open** http://localhost:3000
2. **Sign in** with your credentials
3. **Verify** you can see the main QA application interface
4. **Check** that you have a project selected (top-left dropdown)

### **Step 2: Test File Import**
1. **Click** the "Import" button in the header
2. **Select** `sample-test-cases.csv` file
3. **Watch** the browser console for debug messages
4. **Check** if the Import Preview Dialog opens
5. **Review** the column mappings and preview
6. **Click** "Import" to proceed

### **Step 3: Test Enhanced Paste**
1. **Click** the "Paste" button in the header
2. **Paste** this sample data:
   ```csv
   Test ID,Test Case Name,Description,Priority,Status
   TC001,Login Test,Verify user login,High,Pending
   TC002,Logout Test,Verify user logout,Medium,Pending
   ```
3. **Check** format detection and preview
4. **Click** "Import" to proceed

## 🔍 **Debug Information Added**

### **Console Logging**
The following debug information is now logged to the browser console:

```
💾 Saving imported test cases to database...
🔍 Current project ID: [project-id]
📊 Number of test cases to import: [count]
🔄 Processing test case 1: [test-case-name]
💾 Attempting to save test case 1: [test-case-name]
🔍 Creating test case with data: [test-case-data]
📊 Database data to insert: [database-data]
✅ Test case created successfully: [result]
❌ Database error creating test case: [error]
```

### **Validation Checks**
- ✅ **Project ID validation** - Ensures a project is selected
- ✅ **Authentication check** - Verifies user is logged in
- ✅ **Data validation** - Validates required fields
- ✅ **Error handling** - Proper error reporting

## 🛠️ **Common Issues and Solutions**

### **Issue 1: "No project selected"**
**Solution:**
1. Ensure you're logged in
2. Check the project dropdown in the top-left
3. Select a project if none is selected
4. Wait for project data to load

### **Issue 2: "Authentication required"**
**Solution:**
1. Sign out and sign back in
2. Check if your session is valid
3. Clear browser cache and cookies
4. Try in an incognito/private window

### **Issue 3: "Database permission denied"**
**Solution:**
1. Verify RLS policies are set up in Supabase
2. Check if the user has proper permissions
3. Ensure the database schema is correct
4. Check Supabase logs for detailed errors

### **Issue 4: "Import Preview Dialog doesn't open"**
**Solution:**
1. Check browser console for JavaScript errors
2. Verify the file format is supported (.csv, .xlsx)
3. Ensure the file has data rows
4. Check if the file is corrupted

## 📊 **Expected Behavior**

### **Successful Import:**
1. ✅ File upload shows progress
2. ✅ Import Preview Dialog opens
3. ✅ Column mappings are detected
4. ✅ Preview shows first 5 rows
5. ✅ Validation warnings appear (if any)
6. ✅ Import button is enabled
7. ✅ Test cases are saved to database
8. ✅ Success toast notification appears
9. ✅ Test cases appear in the table

### **Failed Import:**
1. ❌ Error toast notification appears
2. ❌ Detailed error in console
3. ❌ No test cases are saved
4. ❌ Import dialog closes

## 🔧 **Testing Checklist**

- [ ] **User is logged in**
- [ ] **Project is selected**
- [ ] **File format is supported** (.csv, .xlsx)
- [ ] **File has valid data**
- [ ] **Browser console is open** (F12)
- [ ] **Network tab shows requests**
- [ ] **No JavaScript errors**

## 📝 **Sample Test Data**

### **CSV Format:**
```csv
Test ID,Test Case Name,Description,Priority,Status
TC001,Login Test,Verify user login,High,Pending
TC002,Logout Test,Verify user logout,Medium,Pending
TC003,Search Test,Verify search functionality,Low,Pending
```

### **Excel Format:**
Create an Excel file with the same columns and data.

## 🚀 **Next Steps**

1. **Test the import** with the steps above
2. **Check the console** for debug messages
3. **Report any errors** with the console output
4. **Verify test cases** appear in the table
5. **Test the paste functionality** as well

## 📞 **If Issues Persist**

If you're still experiencing issues:

1. **Copy the console output** (all debug messages)
2. **Note the exact error messages**
3. **Check the Network tab** for failed requests
4. **Verify your Supabase setup** is correct
5. **Test with a simple CSV file** first

---

**Ready to test!** Open http://localhost:3000 and follow the steps above. 