import { NextRequest, NextResponse } from 'next/server';

export async function GET(request: NextRequest) {
  try {
    // Get all environment variables
    const envVars = {
      NODE_ENV: process.env.NODE_ENV,
      RENDER: process.env.RENDER,
      AUTOMATION_ENV: process.env.AUTOMATION_ENV,
      PYTHON_PATH: process.env.PYTHON_PATH,
      VERCEL: process.env.VERCEL,
      RAILWAY_ENVIRONMENT: process.env.RAILWAY_ENVIRONMENT,
      HEROKU_APP_NAME: process.env.HEROKU_APP_NAME,
      PORT: process.env.PORT,
      NEXT_PUBLIC_APP_URL: process.env.NEXT_PUBLIC_APP_URL
    };

    // Check if we're in a deployed environment
    const isDeployed = process.env.NODE_ENV === 'production' || 
                      process.env.VERCEL === '1' || 
                      process.env.RENDER === 'true' ||
                      process.env.RAILWAY_ENVIRONMENT ||
                      process.env.HEROKU_APP_NAME;

    return NextResponse.json({
      success: true,
      data: {
        environmentVariables: envVars,
        isDeployed: isDeployed,
        platform: process.platform,
        timestamp: new Date().toISOString()
      }
    });

  } catch (error) {
    return NextResponse.json(
      { 
        success: false,
        error: 'Failed to get environment info',
        details: error instanceof Error ? error.message : 'Unknown error'
      },
      { status: 500 }
    );
  }
} 