import { NextRequest, NextResponse } from 'next/server';
import { exec } from 'child_process';
import { promisify } from 'util';
import { writeFile, unlink } from 'fs/promises';
import { join } from 'path';
import { supabase } from '@/lib/supabase'

const execAsync = promisify(exec);

export async function POST(request: NextRequest) {
  try {
    // Check authentication
    const { data: { user }, error: authError } = await supabase.auth.getUser()
    
    if (authError || !user) {
      return NextResponse.json(
        { error: 'Unauthorized - Authentication required' },
        { status: 401 }
      )
    }

    const body = await request.json();
    const { scriptContent, scriptName = 'automation_script.py' } = body;

    if (!scriptContent) {
      return NextResponse.json({
        success: false,
        error: 'Script content is required'
      });
    }

    // Log the automation request
    const clientIP = request.headers.get('x-forwarded-for') || 'unknown'
    console.log(`Python automation request from user ${user.email} (IP: ${clientIP})`)

    // Check if we're in a deployed environment
    const isDeployed = process.env.NODE_ENV === 'production' || 
                      process.env.VERCEL === '1' || 
                      process.env.RENDER === 'true' ||
                      process.env.RAILWAY_ENVIRONMENT ||
                      process.env.HEROKU_APP_NAME;

    console.log('🚀 Python script execution request...');
    console.log('Script name:', scriptName);
    console.log('Is Deployed:', isDeployed);
    console.log('Environment:', process.env.NODE_ENV);

    if (isDeployed) {
      // In deployed environment, provide instructions for local execution
      const localInstructions = `
🚀 **Python Script Execution Instructions**

Since this is a deployed environment, Python scripts need to be run locally on your machine.

**To run this script locally:**

1. **Save the script content to a file:** ${scriptName}
2. **Open terminal/command prompt**
3. **Navigate to your project directory**
4. **Run the command:**
   \`\`\`bash
   python3 "${scriptName}"
   \`\`\`

**Prerequisites:**
- Python 3.7+ installed
- Required packages: selenium, appium-python-client
- Chrome/Chromium browser
- Appium server (for mobile testing)

**Script Content:**
\`\`\`python
${scriptContent}
\`\`\`

**Alternative:**
You can also run scripts directly from your local development environment where Python is available.

**Environment:** Production (Deployed)
      `;

      return NextResponse.json({
        success: true,
        data: {
          output: localInstructions,
          error: null,
          environment: 'Production (Deployed)',
          executionTime: new Date().toISOString(),
          testSuccess: true,
          deployed: true,
          localExecutionRequired: true,
          scriptName: scriptName
        }
      });
    }

    // For local development, execute the script
    const pythonPath = join(process.cwd(), 'automation-env', 'bin', 'python3');

    // Create temporary script file
    const tempDir = join(process.cwd(), 'temp');
    const scriptPath = join(tempDir, scriptName);

    try {
      // Ensure temp directory exists
      await execAsync(`mkdir -p ${tempDir}`);
      
      // Write script to file
      await writeFile(scriptPath, scriptContent);
      console.log('✅ Script written to:', scriptPath);

      // Run the script
      console.log('🔄 Executing Python script...');
      const { stdout, stderr } = await execAsync(`${pythonPath} ${scriptPath}`, {
        timeout: 300000, // 5 minutes timeout
        env: {
          ...process.env,
          PYTHONUNBUFFERED: '1'
        }
      });

      console.log('✅ Script execution completed');
      console.log('Output:', stdout);
      if (stderr) console.log('Errors:', stderr);

      // Clean up
      try {
        await unlink(scriptPath);
        console.log('✅ Temporary script cleaned up');
      } catch (cleanupError) {
        console.log('⚠️ Cleanup warning:', cleanupError);
      }

      return NextResponse.json({
        success: true,
        data: {
          output: stdout,
          error: stderr || null,
          environment: 'Local Development',
          executionTime: new Date().toISOString(),
          testSuccess: !stderr || stderr.trim() === '',
          deployed: false
        }
      });

    } catch (execError: any) {
      console.error('❌ Script execution failed:', execError);
      
      // Clean up on error
      try {
        await unlink(scriptPath);
      } catch (cleanupError) {
        console.log('⚠️ Cleanup warning:', cleanupError);
      }

      return NextResponse.json({
        success: false,
        error: 'Script execution failed',
        details: execError.message,
        data: {
          output: execError.stdout || '',
          stderr: execError.stderr || '',
          environment: 'Local Development',
          testSuccess: false,
          deployed: false
        }
      });
    }

  } catch (error) {
    console.error('❌ API error:', error);
    return NextResponse.json({
      success: false,
      error: 'API error',
      details: error instanceof Error ? error.message : 'Unknown error'
    });
  }
} 