import { NextRequest, NextResponse } from 'next/server';
import { exec } from 'child_process';
import { promisify } from 'util';

const execAsync = promisify(exec);

export async function POST(request: NextRequest) {
  try {
    console.log('🔧 Installing Python dependencies...');
    
    const results: {
      venvCreate: { success: boolean; message?: string; error?: string } | null;
      pipUpgrade: { success: boolean; message?: string; error?: string } | null;
      seleniumInstall: { success: boolean; message?: string; error?: string } | null;
      webdriverInstall: { success: boolean; message?: string; error?: string } | null;
      appiumInstall: { success: boolean; message?: string; error?: string } | null;
    } = {
      venvCreate: null,
      pipUpgrade: null,
      seleniumInstall: null,
      webdriverInstall: null,
      appiumInstall: null
    };

    // Create virtual environment
    try {
      console.log('📁 Creating virtual environment...');
      const { stdout } = await execAsync('python3 -m venv $HOME/qa-automation-env');
      results.venvCreate = {
        success: true,
        message: 'Virtual environment created successfully'
      };
      console.log('✅ Virtual environment created');
    } catch (error) {
      results.venvCreate = {
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error'
      };
      console.log('❌ Virtual environment creation failed:', error);
    }

    // Upgrade pip first
    try {
      console.log('📦 Upgrading pip...');
      const { stdout } = await execAsync('$HOME/qa-automation-env/bin/pip install --upgrade pip');
      results.pipUpgrade = {
        success: true,
        message: 'Pip upgraded successfully'
      };
      console.log('✅ Pip upgraded');
    } catch (error) {
      results.pipUpgrade = {
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error'
      };
      console.log('❌ Pip upgrade failed:', error);
    }

    // Install Selenium
    try {
      console.log('🌐 Installing Selenium...');
      const { stdout } = await execAsync('$HOME/qa-automation-env/bin/pip install selenium');
      results.seleniumInstall = {
        success: true,
        message: 'Selenium installed successfully'
      };
      console.log('✅ Selenium installed');
    } catch (error) {
      results.seleniumInstall = {
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error'
      };
      console.log('❌ Selenium installation failed:', error);
    }

    // Install WebDriver Manager
    try {
      console.log('🔧 Installing WebDriver Manager...');
      const { stdout } = await execAsync('$HOME/qa-automation-env/bin/pip install webdriver-manager');
      results.webdriverInstall = {
        success: true,
        message: 'WebDriver Manager installed successfully'
      };
      console.log('✅ WebDriver Manager installed');
    } catch (error) {
      results.webdriverInstall = {
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error'
      };
      console.log('❌ WebDriver Manager installation failed:', error);
    }

    // Install Appium Python Client
    try {
      console.log('📱 Installing Appium Python Client...');
      const { stdout } = await execAsync('$HOME/qa-automation-env/bin/pip install Appium-Python-Client');
      results.appiumInstall = {
        success: true,
        message: 'Appium Python Client installed successfully'
      };
      console.log('✅ Appium Python Client installed');
    } catch (error) {
      results.appiumInstall = {
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error'
      };
      console.log('❌ Appium Python Client installation failed:', error);
    }

    // Check if all installations were successful
    const allSuccessful = Object.values(results).every(result => result?.success);

    return NextResponse.json({
      success: true,
      data: {
        results,
        allSuccessful,
        message: allSuccessful ? 'All dependencies installed successfully' : 'Some dependencies failed to install',
        timestamp: new Date().toISOString()
      }
    });

  } catch (error) {
    console.error('❌ Installation process failed:', error);
    return NextResponse.json(
      { 
        success: false,
        error: 'Failed to install dependencies',
        details: error instanceof Error ? error.message : 'Unknown error'
      },
      { status: 500 }
    );
  }
} 