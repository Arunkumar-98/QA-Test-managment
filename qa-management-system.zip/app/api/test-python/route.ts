import { NextRequest, NextResponse } from 'next/server';
import { exec } from 'child_process';
import { promisify } from 'util';
import * as fs from 'fs';

const execAsync = promisify(exec);

export async function GET(request: NextRequest) {
  try {
    const results: {
      pythonPaths: Array<{
        path: string;
        version: string | null;
        exists: boolean;
        error?: string;
      }>;
      seleniumCheck: {
        success: boolean;
        version?: string;
        error?: string;
      } | null;
      webdriverCheck: {
        success: boolean;
        message?: string;
        error?: string;
      } | null;
      chromeCheck: {
        success: boolean;
        path?: string;
        error?: string;
      } | null;
    } = {
      pythonPaths: [],
      seleniumCheck: null,
      webdriverCheck: null,
      chromeCheck: null
    };

    // Check different Python paths
    const homeDir = process.env.HOME || '/opt/render';
    const pythonPaths = [
      `${homeDir}/qa-automation-env/bin/python3`,
      '/usr/bin/python3',
      process.env.PYTHON_PATH
    ].filter((path): path is string => Boolean(path));

    for (const path of pythonPaths) {
      try {
        if (fs.existsSync(path)) {
          const { stdout } = await execAsync(`${path} --version`);
          results.pythonPaths.push({
            path,
            version: stdout.trim(),
            exists: true
          });
        } else {
          results.pythonPaths.push({
            path,
            version: null,
            exists: false
          });
        }
      } catch (error) {
        results.pythonPaths.push({
          path,
          version: null,
          exists: false,
          error: error instanceof Error ? error.message : 'Unknown error'
        });
      }
    }

    // Test Selenium with the first available Python
    const availablePython = results.pythonPaths.find(p => p.exists);
    if (availablePython) {
      try {
        const { stdout } = await execAsync(`${availablePython.path} -c "import selenium; print('Selenium version:', selenium.__version__)"`);
        results.seleniumCheck = {
          success: true,
          version: stdout.trim()
        };
      } catch (error) {
        results.seleniumCheck = {
          success: false,
          error: error instanceof Error ? error.message : 'Unknown error'
        };
      }

      // Test WebDriver Manager
      try {
        const { stdout } = await execAsync(`${availablePython.path} -c "from webdriver_manager.chrome import ChromeDriverManager; print('WebDriver Manager available')"`);
        results.webdriverCheck = {
          success: true,
          message: stdout.trim()
        };
      } catch (error) {
        results.webdriverCheck = {
          success: false,
          error: error instanceof Error ? error.message : 'Unknown error'
        };
      }
    }

    // Check Chrome
    try {
      const { stdout } = await execAsync('which google-chrome');
      results.chromeCheck = {
        success: true,
        path: stdout.trim()
      };
    } catch (error) {
      results.chromeCheck = {
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error'
      };
    }

    return NextResponse.json({
      success: true,
      data: results,
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    return NextResponse.json(
      { 
        success: false,
        error: 'Failed to test Python environment',
        details: error instanceof Error ? error.message : 'Unknown error'
      },
      { status: 500 }
    );
  }
} 