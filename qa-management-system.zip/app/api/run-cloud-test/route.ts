import { NextRequest, NextResponse } from 'next/server';
import { exec } from 'child_process';
import { promisify } from 'util';
import * as fs from 'fs';
import * as path from 'path';

const execAsync = promisify(exec);

export async function POST(request: NextRequest) {
  try {
    const { scriptContent, scriptName } = await request.json();

    if (!scriptContent) {
      return NextResponse.json(
        { error: 'Script content is required' },
        { status: 400 }
      );
    }

    console.log('🚀 Cloud Test Execution Started');
    console.log(`📝 Script Name: ${scriptName || 'test_script'}`);

    // Check if cloud environment is available
    const cloudEnvPath = '/opt/qa-automation/environment.json';
    const cloudPythonPath = '/opt/qa-automation-env/bin/python3';
    
    if (!fs.existsSync(cloudEnvPath) || !fs.existsSync(cloudPythonPath)) {
      return NextResponse.json({
        success: false,
        environment: 'local',
        message: 'Cloud environment not available. Running in local mode.',
        instructions: 'Please run tests locally or set up cloud environment.'
      });
    }

    // Create temporary script file
    const tempScriptPath = path.join('/tmp', `${scriptName || 'test'}_${Date.now()}.py`);
    fs.writeFileSync(tempScriptPath, scriptContent);

    try {
      // Execute script using cloud Python environment
      const { stdout, stderr } = await execAsync(`${cloudPythonPath} "${tempScriptPath}"`, {
        timeout: 300000, // 5 minutes
        env: {
          ...process.env,
          PATH: `/opt/qa-automation-env/bin:${process.env.PATH}`,
          PYTHONPATH: `/opt/qa-automation-env/lib/python3.8/site-packages`
        }
      });

      // Clean up temporary file
      try {
        fs.unlinkSync(tempScriptPath);
      } catch (cleanupError) {
        console.warn('⚠️ Failed to cleanup temporary script:', cleanupError);
      }

      console.log('✅ Cloud test execution completed');

      return NextResponse.json({
        success: true,
        environment: 'cloud',
        result: {
          stdout: stdout,
          stderr: stderr,
          success: true
        }
      });

    } catch (executionError: any) {
      // Clean up temporary file
      try {
        fs.unlinkSync(tempScriptPath);
      } catch (cleanupError) {
        console.warn('⚠️ Failed to cleanup temporary script:', cleanupError);
      }

      console.error('❌ Cloud test execution failed:', executionError);

      return NextResponse.json({
        success: false,
        environment: 'cloud',
        error: executionError.message,
        result: {
          stdout: '',
          stderr: executionError.stderr || executionError.message,
          success: false
        }
      });
    }

  } catch (error) {
    console.error('❌ Cloud test execution error:', error);
    return NextResponse.json(
      { 
        success: false,
        error: 'Failed to execute cloud test',
        details: error instanceof Error ? error.message : 'Unknown error'
      },
      { status: 500 }
    );
  }
} 