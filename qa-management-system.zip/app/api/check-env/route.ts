import { NextRequest, NextResponse } from 'next/server';
import { exec } from 'child_process';
import { promisify } from 'util';
import { join } from 'path';
import * as fs from 'fs';

const execAsync = promisify(exec);

export async function GET(request: NextRequest) {
  try {
    // Check if we're in a deployed environment
    const isDeployed = process.env.NODE_ENV === 'production' || 
                      process.env.VERCEL === '1' || 
                      process.env.RENDER === 'true' ||
                      process.env.RAILWAY_ENVIRONMENT ||
                      process.env.HEROKU_APP_NAME ||
                      process.env.NEXT_PUBLIC_APP_URL?.includes('onrender.com') ||
                      process.env.NEXT_PUBLIC_APP_URL?.includes('render.com') ||
                      process.platform === 'linux' && process.env.HOME === '/opt/render';
    
    console.log('🔍 Deployment detection:', {
      NODE_ENV: process.env.NODE_ENV,
      VERCEL: process.env.VERCEL,
      RENDER: process.env.RENDER,
      RAILWAY_ENVIRONMENT: process.env.RAILWAY_ENVIRONMENT,
      HEROKU_APP_NAME: process.env.HEROKU_APP_NAME,
      NEXT_PUBLIC_APP_URL: process.env.NEXT_PUBLIC_APP_URL,
      isDeployed
    });
    
    // Check if cloud automation environment is available
    const homeDir = process.env.HOME || '/opt/render';
    const cloudPythonPath = process.env.PYTHON_PATH || `${homeDir}/qa-automation-env/bin/python3`;
    const hasCloudEnvironment = fs.existsSync(cloudPythonPath);
    console.log('🔍 Cloud environment check:', { homeDir, cloudPythonPath, hasCloudEnvironment });

    console.log('🔍 Checking Python environment...');
    console.log('Platform:', process.platform);
    console.log('Environment:', process.env.NODE_ENV);
    console.log('Is Deployed:', isDeployed);

    if (isDeployed) {
      console.log('☁️ Deployed environment detected, checking cloud automation...');
      // Check if cloud automation environment is available
      if (hasCloudEnvironment) {
        // Cloud environment is available - check actual dependencies
        console.log('☁️ Cloud automation environment detected');
        console.log('🔍 Cloud Python path exists:', cloudPythonPath);
        
        try {
          // Check Python
          console.log('🔍 Using Python path:', cloudPythonPath);
          const { stdout: pythonVersion } = await execAsync(`${cloudPythonPath} --version`);
          console.log('✅ Cloud Python found:', pythonVersion.trim());
          
          // Check Selenium
          let seleniumAvailable = false;
          let seleniumVersion = '';
          try {
            console.log('🔍 Checking Selenium with path:', cloudPythonPath);
            const { stdout } = await execAsync(`${cloudPythonPath} -c "import selenium; print('Selenium version:', selenium.__version__)"`);
            seleniumAvailable = true;
            seleniumVersion = stdout.trim();
            console.log('✅ Selenium check successful:', seleniumVersion);
          } catch (error) {
            console.log('❌ Selenium not found in cloud environment:', error);
          }
          
          // Check WebDriver Manager
          let webdriverManagerAvailable = false;
          let webdriverManagerVersion = '';
          try {
            console.log('🔍 Checking WebDriver Manager with path:', cloudPythonPath);
            const { stdout } = await execAsync(`${cloudPythonPath} -c "from webdriver_manager.chrome import ChromeDriverManager; print('WebDriver Manager available')"`);
            webdriverManagerAvailable = true;
            webdriverManagerVersion = 'Available';
            console.log('✅ WebDriver Manager check successful');
          } catch (error) {
            console.log('❌ WebDriver Manager not found in cloud environment:', error);
          }
          
          // Check Chrome
          let chromeAvailable = false;
          let chromePath = '';
          try {
            const { stdout } = await execAsync('which google-chrome');
            chromePath = stdout.trim();
            chromeAvailable = true;
          } catch (error) {
            console.log('❌ Chrome not found in cloud environment');
          }
          
          const isReady = seleniumAvailable && webdriverManagerAvailable && chromeAvailable;
          
          return NextResponse.json({
            success: true,
            data: {
              status: isReady ? 'Environment Ready' : 'Environment Incomplete',
              isReady: isReady,
              platform: process.platform,
              isDeployed: true,
              hasCloudEnvironment: true,
              pythonVersion: pythonVersion.trim(),
              seleniumAvailable: seleniumAvailable,
              selenium: seleniumAvailable ? seleniumVersion : 'Not Available',
              webdriverManagerAvailable: webdriverManagerAvailable,
              webdriverManager: webdriverManagerAvailable ? webdriverManagerVersion : 'Not Available',
              chrome: chromeAvailable ? chromePath : 'Not Available',
              environment: 'Cloud (Production)',
              missing: [],
              localExecutionRequired: false
            }
          });
          
                  } catch (error) {
            console.error('❌ Error checking cloud environment:', error);
            // Continue to fallback if there's an error
          }
      }
      
      console.log('❌ Cloud environment not available, using fallback');
      // Fallback to local execution instructions
      const localInstructions = `
🚀 **Environment Check for Deployed Application**

Since this is a deployed environment, Python automation scripts need to be run locally on your machine.

**Local Environment Requirements:**

✅ **Python 3.7+** - Install from python.org
✅ **Selenium** - \`pip install selenium\`
✅ **WebDriver Manager** - \`pip install webdriver-manager\`
✅ **Appium Python Client** - \`pip install Appium-Python-Client\`
✅ **Chrome/Chromium Browser** - Install latest version

**To set up local environment:**

1. **Install Python 3.7+**
2. **Create virtual environment:**
   \`\`\`bash
   python3 -m venv automation-env
   source automation-env/bin/activate  # On Windows: automation-env\\Scripts\\activate
   \`\`\`

3. **Install dependencies:**
   \`\`\`bash
   pip install selenium webdriver-manager Appium-Python-Client
   \`\`\`

4. **Run tests locally:**
   \`\`\`bash
   python3 your_test_script.py
   \`\`\`

**Environment:** Production (Deployed)
**Status:** Local Execution Required
      `;

      return NextResponse.json({
        success: true,
        data: {
          status: 'Local Execution Required',
          isReady: false,
          platform: process.platform,
          isDeployed: true,
          hasCloudEnvironment: false,
          pythonVersion: 'Local Installation Required',
          seleniumAvailable: false,
          selenium: 'Local Installation Required',
          webdriverManagerAvailable: false,
          webdriverManager: 'Local Installation Required',
          chrome: 'Local Installation Required',
          environment: 'Production (Deployed)',
          missing: ['Python', 'Selenium', 'WebDriver Manager', 'Chrome/Chromium'],
          localInstructions: localInstructions,
          localExecutionRequired: true
        }
      });
    }

    // For local development, check actual environment
    const pythonPath = join(process.cwd(), 'automation-env', 'bin', 'python3');

    // Check Python availability
    let pythonVersion = '';
    try {
      const { stdout } = await execAsync(`${pythonPath} --version`);
      pythonVersion = stdout.trim();
      console.log('✅ Python found:', pythonVersion);
    } catch (error) {
      console.log('❌ Python not found:', error);
      return NextResponse.json({
        success: false,
        error: 'Python not available',
        data: {
          python: 'Not Available',
          selenium: 'Not Available',
          webdriverManager: 'Not Available',
          chrome: 'Not Available',
          environment: 'Local Development',
          localExecutionRequired: false
        }
      });
    }

    // Check Selenium
    let seleniumAvailable = false;
    let seleniumVersion = '';
    try {
      const { stdout } = await execAsync(`${pythonPath} -c "import selenium; print('Selenium version:', selenium.__version__)"`);
      console.log('✅ Selenium found:', stdout.trim());
      seleniumAvailable = true;
      seleniumVersion = stdout.trim();
    } catch (error) {
      console.log('❌ Selenium not found:', error);
    }

    // Check WebDriver Manager
    let webdriverManagerAvailable = false;
    let webdriverManagerVersion = '';
    try {
      const { stdout } = await execAsync(`${pythonPath} -c "from webdriver_manager.chrome import ChromeDriverManager; print('WebDriver Manager available')"`);
      console.log('✅ WebDriver Manager found:', stdout.trim());
      webdriverManagerAvailable = true;
      webdriverManagerVersion = 'Available';
    } catch (error) {
      console.log('❌ WebDriver Manager not found:', error);
    }

    // Check Chrome/Chromium availability
    let chromeAvailable = false;
    let chromePath = '';
    try {
      const { stdout } = await execAsync('which google-chrome');
      chromePath = stdout.trim();
      console.log('✅ Chrome found locally:', chromePath);
      chromeAvailable = true;
    } catch (error) {
      console.log('❌ Chrome not found, trying chromium');
      try {
        const { stdout } = await execAsync('which chromium-browser');
        chromePath = stdout.trim();
        console.log('✅ Chromium found:', chromePath);
        chromeAvailable = true;
      } catch (error2) {
        console.log('❌ Neither Chrome nor Chromium found, checking macOS Applications');
        try {
          // Check for Chrome in macOS Applications folder
          const { stdout } = await execAsync('ls /Applications/ | grep -i chrome');
          if (stdout.trim()) {
            chromePath = '/Applications/Google Chrome.app';
            console.log('✅ Chrome found in macOS Applications:', chromePath);
            chromeAvailable = true;
          }
        } catch (error3) {
          console.log('❌ Chrome not found in macOS Applications either');
        }
      }
    }

    // Determine overall status
    const hasPython = pythonVersion !== '';
    const hasSelenium = seleniumAvailable;
    const hasWebDriver = webdriverManagerAvailable;
    const hasChrome = chromeAvailable;
    
    const isReady = hasPython && hasSelenium && hasWebDriver && hasChrome;
    const status = isReady ? 'Environment Ready' : 'Environment Incomplete';

    const result = {
      status: status,
      isReady: isReady,
      platform: process.platform,
      isDeployed: false,
      pythonVersion: pythonVersion || 'Not Available',
      seleniumAvailable: seleniumAvailable,
      selenium: seleniumAvailable ? seleniumVersion : 'Not Available',
      webdriverManagerAvailable: webdriverManagerAvailable,
      webdriverManager: webdriverManagerAvailable ? webdriverManagerVersion : 'Not Available',
      chrome: chromeAvailable ? chromePath : 'Not Available',
      environment: 'Local Development',
      missing: [] as string[],
      localExecutionRequired: false
    };

    // Add missing dependencies to the result
    if (!hasPython) result.missing.push('Python');
    if (!hasSelenium) result.missing.push('Selenium');
    if (!hasWebDriver) result.missing.push('WebDriver Manager');
    if (!hasChrome) result.missing.push('Chrome/Chromium');

    console.log('📊 Environment check result:', result);
    return NextResponse.json({
      success: true,
      data: result
    });

  } catch (error) {
    console.error('❌ Environment check failed:', error);
    return NextResponse.json({
      success: false,
      error: 'Environment check failed',
      data: {
        details: error instanceof Error ? error.message : 'Unknown error',
        environment: 'Local Development',
        localExecutionRequired: false
      }
    });
  }
} 