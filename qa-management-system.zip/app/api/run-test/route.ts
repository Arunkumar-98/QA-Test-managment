import { NextRequest, NextResponse } from 'next/server'
import { exec } from 'child_process'
import { promisify } from 'util'
import { join } from 'path'

const execAsync = promisify(exec)

export async function POST(request: NextRequest) {
  try {
    const { scriptPath, headlessMode = false } = await request.json()

    // Validate script path
    if (!scriptPath) {
      return NextResponse.json({ 
        success: false, 
        error: 'Script path is required' 
      }, { status: 400 })
    }

    // Check if we're in a deployed environment (Render, Vercel, etc.)
    const isDeployed = process.env.NODE_ENV === 'production' || 
                      process.env.VERCEL === '1' || 
                      process.env.RENDER === 'true' ||
                      process.env.RAILWAY_ENVIRONMENT ||
                      process.env.HEROKU_APP_NAME;

    console.log('🔍 Environment check:', {
      NODE_ENV: process.env.NODE_ENV,
      VERCEL: process.env.VERCEL,
      RENDER: process.env.RENDER,
      RAILWAY_ENVIRONMENT: process.env.RAILWAY_ENVIRONMENT,
      HEROKU_APP_NAME: process.env.HEROKU_APP_NAME,
      isDeployed
    });

    if (isDeployed) {
      // In deployed environment, provide instructions for local execution
      const scriptName = scriptPath.split('/').pop() || 'test_script.py';
      const localInstructions = `
🚀 **Test Execution Instructions for Local Environment**

Since this is a deployed environment, Python scripts need to be run locally on your machine.

**To run this test locally:**

1. **Download the script:** ${scriptName}
2. **Open terminal/command prompt**
3. **Navigate to your project directory**
4. **Run the command:**
   \`\`\`bash
   python3 "${scriptPath}"
   \`\`\`

**For headless mode:**
\`\`\`bash
python3 "${scriptPath}" --headless
\`\`\`

**Prerequisites:**
- Python 3.7+ installed
- Required packages: selenium, appium-python-client
- Chrome/Chromium browser
- Appium server (for mobile testing)

**Alternative:**
You can also run tests directly from your local development environment where Python is available.

**Script Details:**
- Path: ${scriptPath}
- Headless Mode: ${headlessMode ? 'Enabled' : 'Disabled'}
- Environment: Production (Deployed)
      `;

      return NextResponse.json({
        success: true,
        output: localInstructions,
        simulation: true,
        deployed: true,
        localExecutionRequired: true,
        scriptPath: scriptPath,
        headlessMode: headlessMode
      })
    }

    // For local development, try to execute the script
    try {
      // Use the virtual environment Python
      const pythonPath = join(process.cwd(), 'automation-env', 'bin', 'python3');
      
      // Sanitize the command to prevent command injection
      const sanitizedPath = scriptPath.replace(/[;&|`$]/g, '')
      const command = headlessMode 
        ? `${pythonPath} "${sanitizedPath}" --headless`
        : `${pythonPath} "${sanitizedPath}"`

      console.log('🔄 Executing command:', command);

      const { stdout, stderr } = await execAsync(command, {
        timeout: 30000, // 30 second timeout
        cwd: process.cwd()
      })

      if (stderr) {
        return NextResponse.json({
          success: false,
          error: `Script execution error: ${stderr}`,
          output: stdout
        })
      }

      return NextResponse.json({
        success: true,
        output: stdout || 'Script executed successfully with no output',
        deployed: false
      })

    } catch (execError: any) {
      return NextResponse.json({
        success: false,
        error: `Execution failed: ${execError.message}`,
        output: execError.stdout || '',
        deployed: false
      })
    }

  } catch (error: any) {
    return NextResponse.json({
      success: false,
      error: `API error: ${error.message}`
    }, { status: 500 })
  }
} 