import { NextRequest, NextResponse } from 'next/server'

export async function GET(request: NextRequest) {
  return NextResponse.json({
    success: true,
    message: 'Simple API route is working!',
    timestamp: new Date().toISOString(),
    debug: {
      nodeEnv: process.env.NODE_ENV,
      envVars: Object.keys(process.env).filter(key => key.includes('GEMINI'))
    }
  })
} 