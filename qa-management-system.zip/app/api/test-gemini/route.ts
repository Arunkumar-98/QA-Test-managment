import { NextRequest, NextResponse } from 'next/server'

export async function GET(request: NextRequest) {
  try {
    console.log('🧪 Testing Gemini API route...')
    
    // Check environment variable
    if (!process.env.GEMINI_API_KEY) {
      return NextResponse.json({
        success: false,
        error: 'GEMINI_API_KEY not found in environment variables',
        debug: {
          envVars: Object.keys(process.env).filter(key => key.includes('GEMINI')),
          nodeEnv: process.env.NODE_ENV
        }
      }, { status: 500 })
    }

    return NextResponse.json({
      success: true,
      message: 'Gemini API route is accessible!',
      debug: {
        apiKeyExists: !!process.env.GEMINI_API_KEY,
        apiKeyLength: process.env.GEMINI_API_KEY?.length,
        apiKeyStartsWith: process.env.GEMINI_API_KEY?.substring(0, 10),
        nodeEnv: process.env.NODE_ENV
      }
    })

  } catch (error) {
    console.error('❌ Gemini API test failed:', error)
    
    return NextResponse.json({
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error',
      debug: {
        apiKeyExists: !!process.env.GEMINI_API_KEY,
        apiKeyLength: process.env.GEMINI_API_KEY?.length,
        apiKeyStartsWith: process.env.GEMINI_API_KEY?.substring(0, 10),
        nodeEnv: process.env.NODE_ENV,
        errorType: error?.constructor?.name
      }
    }, { status: 500 })
  }
} 