# 🔑 Gemini API Key Setup Guide

## 🚨 **Current Issue**
Your Gemini API key is not working on the live app because environment variables are not configured on your deployment platform.

## 🛠️ **How to Fix**

### **Step 1: Local Development Setup**

Create a `.env.local` file in your project root:

```bash
# Gemini API Configuration
GEMINI_API_KEY=AIzaSyBRd6A5zvNlo7b92_sZSTnZJB68Y6-YK2M

# Supabase Configuration (if not already set)
# NEXT_PUBLIC_SUPABASE_URL=your_supabase_url
# NEXT_PUBLIC_SUPABASE_ANON_KEY=your_supabase_anon_key
# SUPABASE_SERVICE_ROLE_KEY=your_service_role_key
```

### **Step 2: Live Deployment Setup**

#### **For Vercel:**
1. Go to [Vercel Dashboard](https://vercel.com/dashboard)
2. Select your QA Management project
3. Go to **Settings** tab
4. Click **Environment Variables**
5. Add new variable:
   - **Name**: `GEMINI_API_KEY`
   - **Value**: `AIzaSyBRd6A5zvNlo7b92_sZSTnZJB68Y6-YK2M`
   - **Environment**: Production (✅), Preview (✅), Development (✅)
6. Click **Save**
7. **Redeploy** your application

#### **For Netlify:**
1. Go to [Netlify Dashboard](https://app.netlify.com/)
2. Select your site
3. Go to **Site settings** → **Environment variables**
4. Add:
   - **Key**: `GEMINI_API_KEY`
   - **Value**: `AIzaSyBRd6A5zvNlo7b92_sZSTnZJB68Y6-YK2M`
5. Click **Save**
6. **Trigger a new deployment**

#### **For Railway:**
1. Go to your Railway project dashboard
2. Click **Variables** tab
3. Add:
   - **Name**: `GEMINI_API_KEY`
   - **Value**: `AIzaSyBRd6A5zvNlo7b92_sZSTnZJB68Y6-YK2M`
4. Click **Add**
5. Railway will automatically redeploy

#### **For Render:**
1. Go to your Render dashboard
2. Select your service
3. Go to **Environment** tab
4. Add:
   - **Key**: `GEMINI_API_KEY`
   - **Value**: `AIzaSyBRd6A5zvNlo7b92_sZSTnZJB68Y6-YK2M`
5. Click **Save Changes**
6. Render will automatically redeploy

### **Step 3: Verify Setup**

After adding the environment variable:

1. **Redeploy** your application
2. **Test the AI features**:
   - Try the **AI Test Case Generator** in the sidebar
   - Try the **AI Enhancement** button in the paste dialog
3. **Check browser console** for any errors
4. **Check deployment logs** for API errors

## 🔍 **Troubleshooting**

### **If it still doesn't work:**

1. **Check API Key Validity**:
   ```bash
   node test-gemini-api.js
   ```

2. **Check Environment Variable**:
   Add this to your API route temporarily:
   ```typescript
   console.log('API Key exists:', !!process.env.GEMINI_API_KEY)
   console.log('API Key length:', process.env.GEMINI_API_KEY?.length)
   ```

3. **Check Deployment Platform**:
   - Ensure you're on the correct deployment
   - Check if environment variables are properly set
   - Look for any deployment errors

4. **Rate Limiting**:
   - Free tier has limits
   - Check if you've exceeded quota

## 📋 **Environment Variables Summary**

Your app needs these environment variables:

```bash
# Required for AI features
GEMINI_API_KEY=AIzaSyBRd6A5zvNlo7b92_sZSTnZJB68Y6-YK2M

# Required for database
NEXT_PUBLIC_SUPABASE_URL=your_supabase_url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_supabase_anon_key
SUPABASE_SERVICE_ROLE_KEY=your_service_role_key
```

## 🎯 **Next Steps**

1. **Add the environment variable** to your deployment platform
2. **Redeploy** the application
3. **Test** the AI features
4. **Remove** any debug console.log statements
5. **Enjoy** your fully functional QA Management System! 🚀

## 📞 **Need Help?**

If you're still having issues:
1. Check your deployment platform's documentation
2. Look at deployment logs
3. Test the API key locally first
4. Ensure you're on the correct deployment URL 