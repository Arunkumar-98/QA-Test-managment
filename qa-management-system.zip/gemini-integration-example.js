const { GoogleGenerativeAI } = require('@google/generative-ai');

// Initialize Gemini API
const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });

// Example functions for QA application integration

/**
 * Generate test cases from a feature description
 */
async function generateTestCases(featureDescription) {
  try {
    const prompt = `
      Generate comprehensive test cases for the following feature:
      
      Feature: ${featureDescription}
      
      Please provide:
      1. Test case title
      2. Test steps
      3. Expected results
      4. Test data requirements
      5. Priority (High/Medium/Low)
      
      Format the response as a structured list.
    `;

    const result = await model.generateContent(prompt);
    return result.response.text();
  } catch (error) {
    console.error('Error generating test cases:', error.message);
    throw error;
  }
}

/**
 * Analyze test results and provide insights
 */
async function analyzeTestResults(testResults) {
  try {
    const prompt = `
      Analyze the following test results and provide insights:
      
      Test Results: ${testResults}
      
      Please provide:
      1. Summary of test execution
      2. Key findings and issues
      3. Recommendations for improvement
      4. Risk assessment
    `;

    const result = await model.generateContent(prompt);
    return result.response.text();
  } catch (error) {
    console.error('Error analyzing test results:', error.message);
    throw error;
  }
}

/**
 * Generate bug report template
 */
async function generateBugReport(bugDescription) {
  try {
    const prompt = `
      Create a detailed bug report for the following issue:
      
      Bug Description: ${bugDescription}
      
      Please include:
      1. Bug title
      2. Severity level
      3. Steps to reproduce
      4. Expected vs actual behavior
      5. Environment details
      6. Additional notes
    `;

    const result = await model.generateContent(prompt);
    return result.response.text();
  } catch (error) {
    console.error('Error generating bug report:', error.message);
    throw error;
  }
}

/**
 * Optimize test suite
 */
async function optimizeTestSuite(testSuite) {
  try {
    const prompt = `
      Analyze and optimize the following test suite:
      
      Test Suite: ${testSuite}
      
      Please provide:
      1. Redundant test cases to remove
      2. Missing test scenarios to add
      3. Test execution order optimization
      4. Performance improvement suggestions
    `;

    const result = await model.generateContent(prompt);
    return result.response.text();
  } catch (error) {
    console.error('Error optimizing test suite:', error.message);
    throw error;
  }
}

// Example usage
async function exampleUsage() {
  try {
    console.log('🧪 Testing Gemini integration...\n');

    // Example 1: Generate test cases
    console.log('📝 Generating test cases...');
    const testCases = await generateTestCases('User login functionality with email and password');
    console.log('Generated test cases:', testCases);

    // Example 2: Analyze test results
    console.log('\n📊 Analyzing test results...');
    const analysis = await analyzeTestResults('5 tests passed, 2 tests failed, 1 test skipped');
    console.log('Analysis:', analysis);

    // Example 3: Generate bug report
    console.log('\n🐛 Generating bug report...');
    const bugReport = await generateBugReport('Login button not responding when clicked');
    console.log('Bug report:', bugReport);

  } catch (error) {
    console.error('Error in example usage:', error.message);
  }
}

// Export functions for use in your QA application
module.exports = {
  generateTestCases,
  analyzeTestResults,
  generateBugReport,
  optimizeTestSuite
};

// Run example if this file is executed directly
if (require.main === module) {
  exampleUsage();
} 