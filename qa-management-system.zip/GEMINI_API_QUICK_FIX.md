# 🚨 Gemini API Quick Fix

## **Error: "Unauthorized - Authentication required"**

This error occurs because the `GEMINI_API_KEY` environment variable is **not configured** on your live deployment.

## 🛠️ **Immediate Fix**

### **Step 1: Add Environment Variable to Your Deployment**

#### **For Vercel:**
1. Go to [Vercel Dashboard](https://vercel.com/dashboard)
2. Select your QA Management project
3. Go to **Settings** → **Environment Variables**
4. Add new variable:
   - **Name**: `GEMINI_API_KEY`
   - **Value**: `AIzaSyBRd6A5zvNlo7b92_sZSTnZJB68Y6-YK2M`
   - **Environment**: Production ✅, Preview ✅, Development ✅
5. Click **Save**
6. **Redeploy** your application

#### **For Netlify:**
1. Go to [Netlify Dashboard](https://app.netlify.com/)
2. Select your site
3. Go to **Site settings** → **Environment variables**
4. Add:
   - **Key**: `GEMINI_API_KEY`
   - **Value**: `AIzaSyBRd6A5zvNlo7b92_sZSTnZJB68Y6-YK2M`
5. Click **Save**
6. **Trigger a new deployment**

#### **For Railway:**
1. Go to your Railway project dashboard
2. Click **Variables** tab
3. Add:
   - **Name**: `GEMINI_API_KEY`
   - **Value**: `AIzaSyBRd6A5zvNlo7b92_sZSTnZJB68Y6-YK2M`
4. Click **Add**
5. Railway will automatically redeploy

#### **For Render:**
1. Go to your Render dashboard
2. Select your service
3. Go to **Environment** tab
4. Add:
   - **Key**: `GEMINI_API_KEY`
   - **Value**: `AIzaSyBRd6A5zvNlo7b92_sZSTnZJB68Y6-YK2M`
5. Click **Save Changes**
6. Render will automatically redeploy

### **Step 2: Verify the Fix**

After adding the environment variable:

1. **Redeploy** your application
2. **Test the AI features**:
   - Try the **AI Test Case Generator** in the sidebar
   - Try the **AI Enhancement** button in the paste dialog
3. **Check browser console** for any errors

## 🔍 **Debugging Steps**

### **Check if Environment Variable is Set:**

Add this temporary debug code to your API route:

```typescript
// Add this at the top of your API route
console.log('🔍 Environment Check:')
console.log('GEMINI_API_KEY exists:', !!process.env.GEMINI_API_KEY)
console.log('GEMINI_API_KEY length:', process.env.GEMINI_API_KEY?.length)
console.log('NODE_ENV:', process.env.NODE_ENV)
```

### **Test API Key Locally:**

Run this command in your project directory:

```bash
node test-gemini-api.js
```

### **Check Deployment Logs:**

1. Go to your deployment platform dashboard
2. Check the **Function Logs** or **Build Logs**
3. Look for any environment variable errors

## 🚨 **Common Issues & Solutions**

### **Issue 1: Environment variable not saved**
**Solution**: Make sure to click "Save" after adding the variable

### **Issue 2: Wrong environment selected**
**Solution**: Ensure the variable is added to **Production** environment

### **Issue 3: Deployment not triggered**
**Solution**: Manually trigger a new deployment after adding the variable

### **Issue 4: API key invalid**
**Solution**: Verify the API key is correct and has proper permissions

## 📋 **Complete Environment Variables List**

Make sure you have these in your deployment:

```bash
# Required for AI features
GEMINI_API_KEY=AIzaSyBRd6A5zvNlo7b92_sZSTnZJB68Y6-YK2M

# Required for database
NEXT_PUBLIC_SUPABASE_URL=https://tbutffculjesqiodwxsh.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRidXRmZmN1bGplc3Fpb2R3eHNoIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTMzNzczNjMsImV4cCI6MjA2ODk1MzM2M30.pbvISdr311KMo7Ia_T3GyDRDCnPBELIWBLw3PkpBSjM

# App Configuration
NEXT_PUBLIC_APP_URL=https://your-app.vercel.app
```

## ⚡ **Quick Test**

After adding the environment variable:

1. **Wait 2-3 minutes** for deployment to complete
2. **Refresh** your application
3. **Try the AI Test Case Generator** again
4. **Check browser console** (F12) for any errors

## 📞 **Still Having Issues?**

If the problem persists:

1. **Double-check** the environment variable name (exact spelling)
2. **Verify** the API key value is correct
3. **Check** deployment logs for errors
4. **Test** the API key locally first
5. **Contact** your deployment platform support

**The fix is simple - just add the `GEMINI_API_KEY` environment variable to your deployment!** 🚀 