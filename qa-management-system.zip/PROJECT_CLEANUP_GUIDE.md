# Project Cleanup Guide - Fixing UUID Project Names

## 🐛 Issue Description

The application was showing project names that appear to be UUIDs or timestamps (like "1753566608710" and "1753566608708") instead of proper project names. This was caused by:

1. **Test Project Creation**: The `testProjectCreation` function was creating test projects with timestamp-based names
2. **Incomplete Cleanup**: These test projects weren't always properly cleaned up
3. **Database Pollution**: Over time, these invalid projects accumulated in the database

## ✅ Solution Implemented

### 1. **Removed Test Project Creation**
- Removed the `testProjectCreation` function that was creating problematic test projects
- Replaced it with a `cleanupTestProjects` function that cleans up existing problematic projects

### 2. **Added Project Name Validation**
- Added validation in `handleAddProject` to prevent creation of projects with:
  - Empty names
  - Timestamp-like names (13+ digits)
  - Very long names (>50 characters)
  - UUID-like patterns

### 3. **Automatic Cleanup**
- The app now automatically cleans up problematic projects on startup
- Identifies and removes projects with invalid names
- Preserves the current project if it's the only one available

## 🧹 Manual Database Cleanup

If you still see UUID project names, run these SQL commands in your Supabase SQL Editor:

### Step 1: Clean up problematic projects
```sql
-- Delete projects with problematic names
DELETE FROM projects 
WHERE name LIKE 'Test Project %' 
   OR name ~ '^[0-9]{13,}$'  -- Timestamp-like names
   OR length(name) > 50       -- Very long names
   OR name ~ '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'  -- UUID format
   OR name = '1753566608710'  -- Specific problematic name
   OR name = '1753566608708'; -- Another specific problematic name

-- Show remaining projects
SELECT id, name, created_at FROM projects ORDER BY created_at DESC;
```

### Step 2: Clean up related data (optional)
```sql
-- Clean up orphaned data for deleted projects
DELETE FROM test_cases 
WHERE project_id NOT IN (SELECT id FROM projects);

DELETE FROM test_suites 
WHERE project_id NOT IN (SELECT id FROM projects);

DELETE FROM documents 
WHERE project_id NOT IN (SELECT id FROM projects);

DELETE FROM important_links 
WHERE project_id NOT IN (SELECT id FROM projects);

DELETE FROM platforms 
WHERE project_id NOT IN (SELECT id FROM projects);
```

## 🔍 Prevention Measures

### 1. **Input Validation**
- Project names are now validated before creation
- Prevents creation of projects with invalid names
- Shows user-friendly error messages

### 2. **Automatic Cleanup**
- App automatically cleans up problematic projects on startup
- Runs cleanup before loading projects
- Logs cleanup activities for debugging

### 3. **Better Error Handling**
- Improved error handling in project creation
- Better logging for debugging issues
- Graceful handling of cleanup failures

## 📋 Validation Rules

The following validation rules are now enforced:

- **Empty names**: Not allowed
- **Timestamp-like names**: Names that are 13+ digits are rejected
- **Very long names**: Names longer than 50 characters are rejected
- **UUID-like names**: Names matching UUID patterns are rejected

## 🚀 After Cleanup

Once the cleanup is complete:

1. **Refresh the application** - The problematic projects should be gone
2. **Create new projects** - Use descriptive names like "Web App Testing" or "Mobile App QA"
3. **Verify functionality** - Ensure project switching and management work correctly

## 🔧 Troubleshooting

### If cleanup doesn't work:
1. Check the browser console for error messages
2. Verify you have proper database permissions
3. Run the SQL commands manually in Supabase
4. Check if there are any foreign key constraints preventing deletion

### If you still see UUID projects:
1. Clear browser cache and localStorage
2. Refresh the application
3. Check if the cleanup function ran successfully in the console
4. Manually delete the projects using the SQL commands above

## 📝 Code Changes Made

### Files Modified:
1. **`components/QAApplication.tsx`**
   - Removed `testProjectCreation` function
   - Added `cleanupTestProjects` function
   - Added project name validation in `handleAddProject`

2. **`components/Sidebar.tsx`**
   - Added basic validation in `handleAddProject`

3. **`lib/cleanup-projects.js`**
   - Created utility script for manual cleanup

### Key Functions:
- `cleanupTestProjects()`: Automatically cleans up problematic projects
- Project name validation: Prevents creation of invalid project names
- Better error handling: More informative error messages

---

**Note**: This cleanup is a one-time fix. The prevention measures will ensure this issue doesn't happen again. 