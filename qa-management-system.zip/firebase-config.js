// Firebase Configuration for QA Test Management
// This file provides configuration for both local and cloud environments

export const localConfig = {
  // Local execution settings
  useLocalExecution: true,
  localPythonPath: './automation-env/bin/python',
  localScriptsDir: './scripts',
  
  // Environment detection
  isDevelopment: process.env.NODE_ENV === 'development',
  isProduction: process.env.NODE_ENV === 'production',
  
  // API endpoints
  apiBaseUrl: process.env.NODE_ENV === 'production' 
    ? 'https://your-production-domain.com/api' 
    : 'http://localhost:3000/api',
  
  // Feature flags
  enableAutomation: true,
  enableEnvironmentCheck: true,
  enableTestExecution: true,
  
  // Timeout settings
  requestTimeout: 30000, // 30 seconds
  executionTimeout: 60000, // 60 seconds
  
  // Logging
  enableDebugLogs: process.env.NODE_ENV === 'development',
  logLevel: process.env.NODE_ENV === 'development' ? 'debug' : 'info'
};

export const firebaseConfig = {
  // Firebase configuration (if needed in the future)
  apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY || '',
  authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN || '',
  projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID || '',
  storageBucket: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET || '',
  messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID || '',
  appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID || ''
};

export default {
  local: localConfig,
  firebase: firebaseConfig
}; 