# 🔧 Gemini API Troubleshooting Guide

## 🚨 **Issue: Environment Variable Set But Still Not Working**

I can see you have the `GEMINI_API_KEY` set in your environment variables, but the API is still returning "Unauthorized - Authentication required". Let's troubleshoot this systematically.

## 🔍 **Step-by-Step Troubleshooting**

### **Step 1: Verify Environment Variable is Active**

#### **Check if the variable is properly deployed:**
1. **Go to your deployment platform** (Vercel/Netlify/etc.)
2. **Check Environment Variables** section
3. **Verify** `GEMINI_API_KEY` is listed
4. **Ensure** it's set for the **Production** environment
5. **Check** the value is exactly: `AIzaSyBRd6A5zvNlo7b92_sZSTnZJB68Y6-YK2M`

#### **Force a new deployment:**
1. **Trigger a new deployment** manually
2. **Wait 3-5 minutes** for deployment to complete
3. **Clear browser cache** and refresh the page

### **Step 2: Check API Key Validity**

#### **Test the API key locally:**
```bash
# Run this in your project directory
node test-gemini-api.js
```

#### **Expected output:**
```
✅ Gemini API key is valid!
Model: gemini-1.5-flash
Response: Hello! I'm Gemini, an AI assistant...
```

#### **If the test fails:**
- The API key might be invalid or expired
- Check if you've exceeded the free tier limits
- Try generating a new API key from Google AI Studio

### **Step 3: Check Deployment Logs**

#### **For Vercel:**
1. Go to your Vercel dashboard
2. Select your project
3. Go to **Functions** tab
4. Click on the function that's failing
5. Check the **Function Logs** for errors

#### **For Netlify:**
1. Go to your Netlify dashboard
2. Select your site
3. Go to **Functions** tab
4. Check the **Function Logs**

#### **Look for these debug messages:**
```
🔍 Environment Check:
GEMINI_API_KEY exists: true
GEMINI_API_KEY length: 39
NODE_ENV: production
```

### **Step 4: Test API Endpoint Directly**

#### **Test the API endpoint:**
1. **Open browser console** (F12)
2. **Try the AI feature** (Test Case Generator)
3. **Look for network requests** in the Network tab
4. **Check the response** from `/api/generate-test-cases`

#### **Expected behavior:**
- Request should go to `/api/generate-test-cases`
- Response should contain generated test cases
- No "Unauthorized" errors

### **Step 5: Check Authentication**

#### **Verify user is logged in:**
1. **Check** if you're logged into the application
2. **Try logging out and back in**
3. **Check** if the user session is valid

#### **Test with a simple API call:**
```javascript
// In browser console
fetch('/api/generate-test-cases', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
  },
  body: JSON.stringify({
    prdTitle: 'Test',
    prdContent: 'Test content',
    project: 'Test Project'
  })
})
.then(response => response.json())
.then(data => console.log(data))
.catch(error => console.error(error))
```

## 🚨 **Common Issues & Solutions**

### **Issue 1: Environment Variable Not Deployed**
**Symptoms**: Variable exists in settings but not in runtime
**Solution**: 
- Force a new deployment
- Check if variable is set for correct environment
- Verify deployment completed successfully

### **Issue 2: API Key Invalid**
**Symptoms**: Local test fails
**Solution**:
- Generate new API key from [Google AI Studio](https://makersuite.google.com/app/apikey)
- Update environment variable with new key
- Redeploy application

### **Issue 3: Rate Limiting**
**Symptoms**: API works sometimes but fails others
**Solution**:
- Check your Google AI Studio usage
- Free tier has limits (15 requests/minute)
- Wait a few minutes and try again

### **Issue 4: Authentication Issues**
**Symptoms**: "Unauthorized - Authentication required"
**Solution**:
- Ensure user is logged in
- Check Supabase authentication
- Try logging out and back in

### **Issue 5: CORS Issues**
**Symptoms**: Network errors in browser console
**Solution**:
- Check if API routes are properly configured
- Verify Next.js API routes are working

## 🔧 **Quick Fixes to Try**

### **Fix 1: Restart Everything**
1. **Redeploy** your application
2. **Clear browser cache**
3. **Log out and back in**
4. **Try the AI feature again**

### **Fix 2: Check API Key Format**
Ensure the API key:
- Starts with `AIzaSy`
- Is exactly 39 characters long
- Has no extra spaces or characters

### **Fix 3: Test Different Environment**
1. **Add the variable** to Development environment
2. **Test locally** with `npm run dev`
3. **If it works locally**, the issue is with production deployment

### **Fix 4: Use Different API Key**
1. **Generate new API key** from Google AI Studio
2. **Update environment variable**
3. **Redeploy application**

## 📊 **Debug Information**

### **Add this to your API route temporarily:**
```typescript
console.log('🔍 Full Debug Info:')
console.log('Request URL:', request.url)
console.log('Request method:', request.method)
console.log('User:', user?.email)
console.log('API Key exists:', !!process.env.GEMINI_API_KEY)
console.log('API Key starts with:', process.env.GEMINI_API_KEY?.substring(0, 10))
console.log('All env vars:', Object.keys(process.env).filter(key => key.includes('GEMINI')))
```

### **Check these in your deployment logs:**
- Environment variable is loaded
- User authentication is working
- API key is valid
- No CORS or network errors

## 🆘 **Still Not Working?**

If none of the above fixes work:

1. **Check deployment platform status** (Vercel/Netlify might be having issues)
2. **Try a different browser** or incognito mode
3. **Contact your deployment platform support**
4. **Check Google AI Studio status** (https://status.ai.google.dev/)

## 📞 **Get Help**

If you're still having issues, please provide:
1. **Deployment platform** (Vercel/Netlify/etc.)
2. **Error messages** from browser console
3. **Deployment logs** from your platform
4. **Results** from `node test-gemini-api.js`

**Let's get your AI features working!** 🚀 