# 🚀 Dynamic Import Functionality Guide

## Overview

The QA Management application now features **enhanced dynamic import functionality** that can intelligently handle various file formats and column mappings. This makes importing test cases much more flexible and user-friendly.

## ✨ New Features

### 1. **Multi-Format Support**
- ✅ **Excel Files** (`.xlsx`, `.xls`)
- ✅ **CSV Files** (`.csv`)
- ✅ **Text Paste** (with CSV detection)

### 2. **Dynamic Column Mapping**
The system automatically maps columns from your files to the correct test case fields, supporting multiple naming conventions:

#### **Test Case Name Mapping**
```
testCase → Test Case → Test Case Name → Test ID → Title → Name → TC Name
```

#### **Description Mapping**
```
description → Description → Desc → Details → Summary → Functional Area
```

#### **Expected Result Mapping**
```
expectedResult → Expected Result → Expected → Expected Outcome → Expected Output
```

#### **Status Mapping**
```
status → Status → Test Status → Execution Status
```

#### **Priority Mapping**
```
priority → Priority → Test Priority → Severity → Importance
```

#### **Category Mapping**
```
category → Category → Test Category → Type → Test Type → Functional Area
```

#### **Assigned Tester Mapping**
```
assignedTester → Assigned Tester → Assigned To → Tester → Owner → Assignee
```

#### **Execution Date Mapping**
```
executionDate → Execution Date → Date → Test Date → Run Date
```

#### **Notes Mapping**
```
notes → Notes → Comments → Remarks → Additional Info
```

#### **Actual Result Mapping**
```
actualResult → Actual Result → Actual → Result → Output
```

#### **Environment Mapping**
```
environment → Environment → Env → Test Environment
```

#### **Prerequisites Mapping**
```
prerequisites → Prerequisites → Pre-requisites → Requirements → Setup
```

#### **Platform Mapping**
```
platform → Platform → OS → Operating System → Device
```

#### **Steps to Reproduce Mapping**
```
stepsToReproduce → Steps to Reproduce → Test Steps → Steps → Procedure → Actions
```

### 3. **Smart Validation & Error Handling**
- ✅ **Automatic field validation**
- ✅ **Data cleaning and formatting**
- ✅ **Graceful error handling**
- ✅ **Partial import success reporting**
- ✅ **Detailed validation warnings**

### 4. **Flexible Data Formats**
The system handles various data formats intelligently:

#### **Case Variations**
- `testCase` → `testcase` → `TESTCASE` → `Test Case`
- `priority` → `Priority` → `PRIORITY`

#### **Spacing Variations**
- `testCase` → `Test Case` → `test_case` → `test-case`

## 📁 How to Use

### **Method 1: File Upload**

1. **Click the "Import" button** in the main header
2. **Select your file** (Excel or CSV)
3. **The system automatically:**
   - Detects the file format
   - Maps columns dynamically
   - Validates the data
   - Imports valid test cases
   - Reports any issues

### **Method 2: CSV Paste**

1. **Click the "Paste" button** in the main header
2. **Paste CSV data** directly into the dialog
3. **The system automatically:**
   - Detects CSV format
   - Maps columns dynamically
   - Creates test cases

### **Method 3: Text Paste**

1. **Click the "Paste" button** in the main header
2. **Paste structured text** with keywords like:
   ```
   Test Case Name
   Description
   Steps: 1. Step one 2. Step two
   Expected: Expected result
   Priority: High
   Status: Pending
   ```

## 📋 Supported File Formats

### **Excel Files (.xlsx, .xls)**
```excel
| Test Case Name | Description | Expected Result | Priority | Status |
|----------------|-------------|-----------------|----------|--------|
| Login Test     | Test login  | User logged in  | High     | Pending|
```

### **CSV Files (.csv)**
```csv
Test Case Name,Description,Expected Result,Priority,Status
Login Test,Test login,User logged in,High,Pending
```

### **Sample CSV Format**
```csv
Test ID,Test Case Name,Functional Area,Description,Test Steps,Expected Result,Priority,Status,Assigned To,Execution Date,Notes,Automation Candidate
TC001,App Launch,App Launch & Initialization,Verify app launches successfully,Open the application,Main Recording Interface displays correctly,Critical,Not Started,,,,,
```

### **Alternative CSV Format (Recording Test Cases)**
```csv
Test ID,Test Case Title,Description,Steps to Reproduce,Expected Result,Priority,Status
TC-R001,Launch Recording Screen,Verify that user can open the recording screen,Launch app → Tap on 'Start Recording',Recording screen loads successfully,Critical,Not Started
TC-R002,Start Recording (Normal Case),Verify recording starts when the mic button is tapped,Tap mic button on the recording screen,Recording starts timer begins,Critical,Not Started
```

## 🔧 Advanced Features

### **Automatic Data Cleaning**
- ✅ Trims whitespace from all text fields
- ✅ Validates enum values (Status, Priority, Category)
- ✅ Provides default values for missing fields
- ✅ Handles empty cells gracefully

### **Validation Rules**
- ✅ **Test Case Name**: Required (auto-generated if missing)
- ✅ **Status**: Must be one of: `Pending`, `Pass`, `Fail`, `In Progress`, `Blocked`
  - **Auto-converts**: `Not Started` → `Pending`, `In Progress` → `In Progress`, etc.
- ✅ **Priority**: Must be one of: `High`, `Medium`, `Low`
  - **Auto-converts**: `Critical` → `High`, `Urgent` → `High`, `Normal` → `Medium`, etc.
- ✅ **Category**: Must be one of: `Functional`, `Non-Functional`, `Regression`, `Smoke`, `Integration`, `Unit`, `E2E`

### **Error Reporting**
The system provides detailed feedback:
- ✅ **Success**: "X test cases imported successfully"
- ✅ **Partial Success**: "X imported, Y failed"
- ✅ **Validation Warnings**: "X rows had validation issues"
- ✅ **Complete Failure**: "Failed to import test cases"

## 🎯 Best Practices

### **File Preparation**
1. **Use clear column headers** (the system will map them automatically)
2. **Include required fields** (Test Case Name is mandatory)
3. **Use consistent data formats** for dates and enums
4. **Test with a small sample** before importing large files

### **Column Naming Tips**
- Use descriptive column names
- Be consistent with naming conventions
- Include variations in your headers if needed

### **Data Quality**
- Clean your data before importing
- Validate enum values match the system's expected values
- Remove any unnecessary formatting

## 🚨 Troubleshooting

### **Common Issues**

#### **"No data found in file"**
- Check that your file has data rows (not just headers)
- Ensure the file format is supported (.xlsx, .xls, .csv)

#### **"Validation warnings"**
- Check the console for specific validation errors
- Verify enum values match the expected options
- Ensure required fields are present

#### **"Partial import success"**
- Some test cases imported successfully
- Check the console for specific failure reasons
- Verify database connectivity and permissions

#### **"Import failed"**
- Check file format and structure
- Verify file is not corrupted
- Check browser console for detailed error messages

### **Debug Tips**
1. **Check browser console** for detailed error messages
2. **Use the sample CSV file** as a reference
3. **Test with a small file** first
4. **Verify column headers** match expected formats

## 📊 Performance

### **Large File Handling**
- ✅ Supports files with hundreds of test cases
- ✅ Processes data in batches
- ✅ Provides progress feedback
- ✅ Handles memory efficiently

### **Optimization Tips**
- Import files in reasonable sizes (100-500 test cases per file)
- Use CSV format for large datasets (smaller file size)
- Close other browser tabs during large imports

## 🔄 Migration from Old System

### **Backward Compatibility**
- ✅ All existing import functionality still works
- ✅ Old file formats are still supported
- ✅ No breaking changes to existing workflows

### **Upgrade Benefits**
- ✅ More flexible column mapping
- ✅ Better error handling
- ✅ CSV support
- ✅ Improved validation

## 📝 Example Files

### **Sample Excel File**
Download `sample-test-cases.xlsx` from the project root

### **Sample CSV File**
Download `sample-test-cases.csv` from the project root

### **Sample Text Format**
```
Test Case: User Login
Description: Verify user can log in with valid credentials
Steps: 1. Enter username 2. Enter password 3. Click login
Expected: User is logged in and redirected to dashboard
Priority: High
Status: Pending
```

## 🎉 Summary

The new dynamic import functionality makes it much easier to import test cases from various sources:

- **No more rigid column requirements**
- **Automatic format detection**
- **Intelligent field mapping**
- **Comprehensive validation**
- **Detailed error reporting**
- **Multiple import methods**

This significantly reduces the time and effort required to import test cases while improving data quality and user experience. 